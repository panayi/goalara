= RVM History, thanks be to Git.

== Release 1.7.0
  * Since this is not read anyway, I might as well have some fun with it!
  * Default rvm_project_rvmrc to off, set rvm_project_rvmrc=1 in ~/.rvmrc to enable. Oh wow, you mean you could toggle it??? Yes. Always could. Wow I should have asked!! Yes... yes you should have... Amazing how much you learn by simply asking a question...
  * Added missing example.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * RVM History, thanks be to Git.
  * Merge pull request #364 from jfredett/master
  * fix typo (doubled 'bison') in arch bootstrap script and in script/notes
  * Merge pull request #363 from aghecht/master
  * Adding missing shell functions
  * Merge pull request #362 from ognevsky/fix-typo-in-implode
  * Fixed typo in implode
  * Correcting install messages.
  * fix local arrays in trusting
  * fix trusting on zsh
  * Merge pull request #361 from zaadjis/master
  * Fixed untrusting rvmrcs.
  * Copy paste can get you into trouble sometimes ;)
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Swiped md5 code from BDSM
  * Merge pull request #359 from agibralter/master
  * Allow hooks directory or hooks to be symlinked.
  * Merge pull request #358 from chrismealy/master
  * Added automake (to get aclocal) to dependencies for Ubuntu.
  * Merge pull request #357 from tabletcorry/master
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * prevent duplicate suffixing
  * cleanup.
  * Cleanly return in case of not in a git repository tree.
  * Add a check to FQ rvm_path
  * Merge pull request #356 from dsedivec/master
  * Allow irb switches to set the prompt mode
  * Merge pull request #354 from lribeiro/master
  * Merge pull request #355 from ncreuschling/master
  * removed duplicate dependency from installation notes
  * we dont need to depend ant dist to build jruby, ant jar is enough and a lot faster
  * Merge pull request #353 from MagLev/MagLev-26355
  * do not require double -- after --name
  * do not pass args before --
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * do not pass args before --
  * Updated to MagLev-26355
  * Merge pull request #352 from meqif/master
  * Fixed zsh bug when glob_subst is set.
  * use a local for the file looping over.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Added popd hijack.
  * Merge pull request #351 from goncalossilva/master
  * added gcdata patch for 1.9.3-preview1
  * added gcdata patch for 1.9.2-p290
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * cleaning mri detection for other rubies
  * Merge pull request #349 from deryldoucette/master
  * remove test output
  * manual printf as find not allways supports it
  * fix detection mri rubies
  * Some cli cleanup.
  * Fixed errant help message. Was displaying 'rvm package' rather than 'rvm pkg' as it should.
  * flipNzBit!
  * Merge pull request #347 from mblair/master
  * so it's like the others
  * tyop.
  * Really? Homebrew? Have another...

== Release 1.6.32
  * Ruby 1.9.3-preview1 is now default 1.9.3
  * Merge pull request #346 from amarshall/rbx-1.2.4
  * Rubinius 1.2.4
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * fix --no-tcmalloc on OSX when user provided options
  * Initial groundwork for "rvm group" feature, untested
  * Merge pull request #345 from tricknotes/master
  * Changed package to pkg on README
  * make rbx work
  * Merge pull request #344 from tsykoduk/master
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * fix bunzip2 error
  * changed package to pkg on help text to correctly reflect real command

== Release 1.6.31
  * git it done man, git it done.
  * NO Effin Comment. I am with @joedamato on this one.
  * Allow 1.9 in dependency check for Rubinius, requiring MRI.

== Release 1.6.30
  * RubyGems 1.8.6 as default, w00t!!!

== Release 1.6.29
  * claening
  * restore jruby hook code, it is already disabled by default
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * no default jruby/ng on install, persist hooks x flag on install
  * make 1.9.3-head working
  * fix reading db
  * Dismount.

== Release 1.6.28
  * "rvm refresh ..." => "rvm reinstall" as suggested by v0n
  * Feature: rvm refresh 1.9.2 ~ equivalent to rvm remove 1.9.2 ; rvm install 1.9.2

== Release 1.6.27
  * Removed ebuilds.
  * Also set CC on Darwin for 1.9 Rubies, for now.
  * Updated ebuild for latest release.

== Release 1.6.26
  * export CC="/usr/bin/gcc-4.2" if darwin11
  * Merge pull request #343 from telemachus/lion
  * Add a note/warning about gcc vs llvm on Lion
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * fix installer to not make jruby hook +x when it was -x once
  * No comment.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * improved jruby support, allow to set per project options (in .rvmrc)
  * Merge pull request #342 from MagLev/MagLev-26231
  * Updated to MagLev-26231
  * update support for ubuntu
  * Merge pull request #341 from anl/master
  * Merge remote-tracking branch 'rvm/master'
  * Adjusted logic.
  * Merge pull request #340 from joshuacronemeyer/master
  * Merge remote branch 'upstream/master'
  * change fetch script to account for the fact that curl wasn't giving an error when it got a 404.  fetch should fail in that case use -f switch to ensure it.
  * Merge pull request #339 from psanford/fix_global_rvm_path
  * Fix "grep: Invalid range end" messages on FreeBSD.
  * Fixed rvm.sh setting path for global installs.
  * Fix FreeBSD "pw groupadd" syntax.
  * Merge pull request #337 from MagLev/MagLev-26197
  * Wrestling the ZSH beastiality beast.
  * Updated to MagLev-26197
  * Fixed incorrect formatting and inconsistency.
  * Adjusted testing for teardown.
  * Merge pull request #321 from darren-fhf/master
  * Bugfix in rvmrc generator.
  * Updated ebuild for latest release.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * fix after

== Release 1.6.25
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * fix removing jruby functions
  * jruby hook enabled by default
  * note about after_use hooks
  * fix hooks installation
  * Let us not forget about zsh :)
  * after_use hooks must be executable to be turned on now.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Added rubygems diretory.
  * Fixing unsets.
  * Merge pull request #336 from jzacsh/master
  * Merge branches 'master' and 'master' of git://github.com/wayneeseguin/rvm
  * Fixing bug introduced in 203257a by pull request #333, case-modification is a bash4ism [1].
  * More .gitignore files.
  * pkg
  * pkg!!!
  * hooksssssssssssssssss
  * Minor tweaking of awesome work by mpapis.
  * Merge pull request #335 from mpapis/ng
  * fix after_use hooks, add jruby --ngserver support
  * Good cop. Bad cop.
  * Why... whatever could I be up to?
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * package :)
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * pkg :)
  * Merge pull request #333 from jzacsh/master
  * Missed one.
  * Bombs away!!!
  * pull #333: implified logic for user simply hitting [enter] key.
  * using case in place of if for possible "yes" or "no" in user-response.
  * taking advantage of the printf that was already there; a whee-bit nicer.
  * making sure that the while condition actually make sense. utilizing boolean-ish~ness with bash arithmetic, ease of reasdability. lower-casing response immediately.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge pull request #334 from t-nagamatsu/patch-1
  * Updated ebuild for latest release.
  * Hook code cleanup.
  * Updated ebuild for latest release.

== Release 1.6.24
  * Merge pull request #331 from jrep/master
  * Always store project .rvmrc trust keyed by the full, only slightly munged, path Prune old-style md5-keyed entries during install Mention all this in notes
  * changed each option sequence. unexpected error won't occur to run 'package install zlib' on Mac OS X 10.6. "ERROR: Error running '/*/make install', please read /*/make.install.log"
  * Merge pull request #330 from griff/master
  * simplified prompt for rvmrc trust, infinate loop not a threat, as user can interrupt script at any time.
  * updated copy to no longer reference `less` pager, as it seems cat is used now for security purposes.
  * simplified checking of params.
  * yoda~ish logic from [not, else] to [if, then]
  * Updated ebuild for latest release.

== Release 1.6.23
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Ruby 1.9.2 p290 is now default.
  * Recall the checksum of a trusted project .rvmrc.
  * Added code to set rvm_user_install_flag in scripts/initialize
  * Merge pull request #328 from gabemc/master
  * Merge pull request #329 from biow0lf/master
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * rvmsudo: fix vairable values with spaces
  * Add ruby-1.9.3-head
  * Making md5sum the default executable, to fix an issue on Cygwin, which doesn't have a correctly formatted MACHTYPE.
  * Merge pull request #327 from nibrahim/master
  * Escape grep
  * update instructions for reload
  * fix variable values containing spaces
  * yaml v0.1.4
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Installer adjustment.
  * Merge pull request #326 from arunagw/jruby163_test
  * Tests added for JRuby-1.6.3
  * Merge pull request #325 from terabyte/master
  * Fixed error message when you 'gemset create' before 'use ruby'.
  * Updated ebuild for latest release.

== Release 1.6.22
  * JRuby 1.6.3
  * Merge pull request #323 from andrew/master
  * Merge pull request #324 from mhorbul/master
  * use TMPDIR value or /tmp by default. This will allow to update rvm when /tmp is mounted with noexec flag
  * Updated rails bootstrap script to install rails 3.0.9
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * inform user about reload\!
  * reworked rvmsudo: forward all rvm variables (and possibly more)
  * fix loading/reloading rvm
  * Merge pull request #322 from MagLev/maglev-newMac
  * Handle pre-installed gems for MagLev
  * add libxslt for yum: needed in CentOS 5.6
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * fix capistrano :system for rvm 1.6.21
  * Updated ebuild for latest release.

== Release 1.6.21
  * Merge pull request #320 from koraktor/ruby-1.8.7-p352
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * make rvm ruby lib work properly with 1.9.2
  * Ruby 1.8.7 has been updated to patch level 352
  * Merge pull request #319 from kbrock/master
  * rvm wrapper now properly symlinks to a command with an absolute path
  * fix zsh installation (process env persistance)
  * always export rvm_path (sourced from .rvmrc)
  * silence pushd/popd
  * Merge pull request #318 from danhealy/master
  * rvm_prefix does not have a trailing slash
  * Merge pull request #317 from dplummer/patch-1
  * Fix skipping extract step for REE
  * fix root 'user' installation
  * Merge pull request #316 from tylerhunt/patch-1
  * Fixed a typo in the gemset_empty() warning.
  * Merge pull request #314 from griff/master
  * Merge branch 'master' of https://github.com/wayneeseguin/rvm
  * Restructured how the - separator gets inserted in rvm-prompt to remove the need for sed editing at the end
  * fix defaults to root
  * fix rvm self contained feature
  * Merge pull request #313 from griff/master
  * Found a few log calls that was missed when logging was pulled internal
  * Merge pull request #312 from cobracmder/master
  * made minor grammar changes
  * Merge pull request #311 from cobracmder/patch-1
  * Minor grammar changes
  * Merge pull request #310 from MagLev/MagLev-26063
  * Updated to MagLev-26063
  * Merge pull request #307 from threedaymonk/master
  * Merge pull request #309 from MagLev/maglev-newMac
  * Merge pull request #308 from justinko/master
  * Fix problem causing selector to download/compile curl
  * Merge pull request #306 from MagLev/maglev-newMac
  * spellcheck
  * Correct spelling of possessive its
  * Fix up GemStone version for "rvm install maglev-head"
  * rvm_gemstone_version
  * Merge pull request #305 from MagLev/maglev-newMac
  * Fix bad location for uncompressed GemStone directory
  * Array! Yay!
  * Merge pull request #304 from iangreenleaf/master
  * Missed a spot! Spot! There you are lil guy!!!
  * Anyone else hear circus musik?
  * Cleanup, aisle MagLev.
  * scripts/base in maglev.
  * Only add users to group if thy aren't members
  * Check users against passwd file
  * Merge pull request #303 from MagLev/maglev-newMac
  * Change so RVM doesn't override preinstalled RubyGems for MagLev
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * bashrc
  * Merge pull request #302 from szTheory/master
  * fixed issue where Result#initialize would blow up if status was false, giving (NoMethodError: undefined method '[]' for false:FalseClass) on result.rb:14
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Try exporting rvm_path.
  * Merge pull request #301 from Spaceghost/master
  * Merge pull request #300 from MagLev/maglev-newMac
  * Made rvm always create a hooks directory.
  * Handled case where MagLev arch was x86-64 but file is i386
  * Merge pull request #298 from mpapis/master
  * Merge pull request #299 from MagLev/MagLev-25987
  * Updated to MagLev-25987
  * fix macport manage script
  * Merge pull request #296 from buysse/improve_rvmsudo
  * Merge pull request #295 from geemus/master
  * Merge pull request #294 from gstark/fix_logging_output_tput_styling
  * Merge pull request #293 from HeSYINUvSBZfxqA/master
  * Merge pull request #297 from remear/master
  * Added strings option to gemset listings. rvm gemset list strings
  * Added support for sudo flags (such as -H) to the rvmsudo script
  * [help] add use docs
  * [help] add uninstall docs
  * [help] add remove docs
  * Removed the unset for rbxopt, allow it for all rbx installs.
  * Detect interactive shell by looking at STDOUT for colorized logging.
  * quote --no-same-owner option with tar command for ree/maglev
  * 2.0.0pre @tmorini :)
  * Merge pull request #292 from mblair/master
  * typo fix
  * Use RVM path.
  * Updated ebuild for latest release.

== Release 1.6.20
  * Updated ebuild for latest release.
  * Truncate logs so that logs reflect last run.
  * A tweaking we will go, a tweaking we will go...
  * rvm_install_args
  * rbx is not compatible with rbx :-p
  * For rbx allow args to be passed through directly to configure.
  * Account for name case.
  * rbx counts too ;)
  * rvm install rbx-2.0.0pre will work tomorrow ;)
  * Updated ebuild for latest release.

== Release 1.6.19
  * Bugfix, we have ruby at this point, might as well use it to generate a yaml output of the env ;).
  * Try that rboyd...
  * Move --no-same-owner inside.
  * Put back an empty file.
  * Merge pull request #291 from indirect/master
  * Only track the latest of each point release in known.
  * Stop forcibly setting BUNDLE_GEMFILE for now, because it stays set forever.
  * Remove bundle shell function for now
  * Added missing sources.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Cleaning up manage script by breaking it out into files.
  * Merge pull request #290 from swhitt/master
  * Running "bundle" by itself is the same thing as running "bundle install".
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Bugfix in installer thanks to yonahw.
  * Merge pull request #289 from mpapis/master
  * fix BUNDLE-INSTALL(1)                                            BUNDLE-INSTALL(1)
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * ignore RybMine configuration
  * handle BUNDLE_GEMFILE, added default for projects that do not provide it
  * Merge pull request #288 from shtirlic/patch-1
  * Fix for zsh.
  * ensure not finding the function.
  * Altered rvm loading.
  * better handling bundler, do not generatecomments for PATH
  * do not create separate bin dir for bundler, let it overwrite gem
  * "life" is the better word than "work" ;)
  * Some manage cleanup.
  * Merge!
  * stars.
  * Acting on comment suggestion from githuh.
  * Merge pull request #287 from mpapis/master
  * fix bundle binstubs
  * Merge pull request #286 from mpapis/master
  * improved bundle commnad
  * Helps to actually git add the file.
  * Account for bundler in rvm itself now.
  * Merge pull request #284 from docwhat/master
  * Merge pull request #285 from mattalbright/master
  * This fixes the bug where system-installed RVM on Mac doesn't properly add the users to the rvm group. To properly add Mac users to the rvm group, list all users that are in the "staff" group, which seems to mean can login.
  * Typo in example rvmrc
  * Merge pull request #283 from ncreuschling/master
  * Escape! Escape!
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * bump version defaults in bootstrap script.
  * fixed typo
  * Merge pull request #282 from MagLev/MagLev-25913
  * Updated ebuild for latest release.

== Release 1.6.18
  * Added lines for bundler users to generated rvmrc (rvm --create --rvmrc use X@Y)
  * Added a comment.
  * Updated ebuild for latest release.

== Release 1.6.17
  * More robust generated rvmrc files, better error handling.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * The proper thing to do is to use autoreconf, not autoconf. Learning autotools proper usage is highly recommended.
  * Updated to MagLev-25913
  * Merge pull request #281 from nwjsmith/master
  * Fix typo
  * Merge pull request #280 from mpapis/master
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * memory note for Rubinius
  * added instructions for opensuse
  * Merge pull request #279 from ajburton/md5_fix
  * fixes test syntax
  * vbatts is correct.
  * Properly denote the default version of JRuby.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Updated ebuild for latest release.

== Release 1.6.16
  * Source packages at the top.
  * Such tender love went into the making of this feature :)
  * Merge pull request #277 from arunagw/jruby_tests
  * Tests added for jruby-1.6.2 #jruby
  * Minor cleaning.
  * Do not switch rubygems on JRuby.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * JRuby 1.6.2, w00t!
  * Updated ebuild for latest release.

== Release 1.6.15
  * Merge pull request #276 from ilikepi/fix_missing_then
  * Add missing "then" to scripts/rubygems
  * Added DESTDIR
  * rubygems script cleanup.
  * Updated ebuild for latest release.

== Release 1.6.14
  * More installer fixes.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * I see stars!
  * Merge pull request #275 from mpapis/master
  * fix compilation with openssl 1.8.6
  * I never thought that I would be doing this :)
  * Updated ebuild for latest release.

== Release 1.6.13
  * WHY was that not executable???
  * More progress cleaning up installer.
  * Look, the cure for stupidity consists of space!
  * Gotcha you lil buggar!
  * More installer refactorings, trying to get to the bottom of that annoying issue.
  * Some cleanup of the rvm-installer.
  * Only append to profile file if it exists.
  * Array start bugfix and gemset script cleanup.
  * Somehow it managed to elude me.
  * Ensure that scripts that should be executable are.
  * Bugfix?
  * Bugfix?
  * If not connected to an interactive session, return.
  * Updated ebuild for latest release.

== Release 1.6.12
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Updated ebuild for latest release.

== Release 1.6.11
  * Merge pull request #271 from adevadeh/patch-1
  * Merge pull request #272 from yonahw/bad_taste_in_branch_naming_accepted_NOT_encouraged
  * Merge pull request #273 from MagLev/MagLev-25876
  * Merge pull request #274 from thomasjachmann/master
  * fixes installer bug introduced in 10.6.10
  * I blame gitflow for this atrocity
  * split bunzip into 2 lines, the one-liner fails in RHEL4 for some reason. 2 lines works for RHEL4, RHEL5, Ubuntu, and MacOS, have not tested anything else
  * Updated to MagLev-25876
  * Updated ebuild for latest release.
  * 1.6.10
  * Merge branch 'master' of github.com:wayneeseguin/rvm into rbx
  * Bugfix: unbound variable in cli.
  * Merge pull request #270 from ahamid/master
  * add switch for explicit user install setting; helpful with root
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * More housecleaning.
  * Merge pull request #269 from pvande/master
  * Fixed postinstall note output.
  * More cleanup.
  * only call the command if it is loaded, first install should not error.
  * Low hanging fruit plucking.
  * Adjusted __rvm_18_compat_ruby to exclude rbx, since we do not want rbx to build rbx.
  * Always load the .rvmrc if in an interactive shell (open new tab in same dir).
  * Clean up some RubyGems-related duplication.
  * Merge pull request #268 from CraigCottingham/rvmselect
  * Merge branch 'master' into rvmselect
  * Merge branch 'rvmselect'
  * Add scripts/functions/developer, from https://gist.github.com/984bd56424be200532d0
  * Merge pull request #267 from CraigCottingham/cleanup-bin
  * Fix call to match() in __rvm_remove_binaries()
  * Began cleaning up the installer.
  * Cleaned up wrapper code some.
  * Thank yøu bhenderson.
  * Updated ebuild for latest release.

== Release 1.6.9
  * Fixed an assinine bug thanks to stepheneb.
  * Properly test for interactive mode.
  * Removed no longer necessary code.
  * Updated ebuild for latest release.
  * The LOFL I am sick of this shit release!
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * LOFL!
  * Merge pull request #266 from MagLev/MagLev-25838
  * Switch to antialias.
  * Corrected ordering.
  * Updated ebuild for latest release.

== Release 1.6.7
  * Synchronizing the code repetition blocks.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Level the playing field.
  * Merge pull request #265 from gabebw/dollar-dollar
  * Use cp -f and rm -f when dealing with /tmp/$$
  * Updated ebuild for latest release.

== Release 1.6.6
  * Updated to MagLev-25838
  * Only if prefix is nonempty.
  * Adjusted __rvm_project_rvmrc()
  * Merge pull request #264 from derekprior/help-updates
  * Works with 1.9.* as well. Added bit about 'rvm rubygems remove' from the rvm website.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * set -fu
  * Merge pull request #263 from meineerde/setup_rvm_group_users-with-no-users
  * Fix setup_rvm_group_users for the case when there are no additional users.
  * Tweaked recursive copy.
  * Add a reset --hard HEAD on rbx build.
  * handle get specially.
  * resolution
  * s/aptitude/apt-get/g Many users of Debian certainly and probably other Debian-derived distros prefer 'apt-get' to 'aptitude'. For whatever reasons [Ubuntu has actually stopped shipping with 'aptitude' by default](http://www.webupd8.org/2010/06/aptitude-removed-from-ubuntu-1010.html). Without debating the technical merits of either tool, I would say this:
  * Merge pull request #259 from matschaffer/patch-1
  * More set -u fun.
  * set -u should be outlawed :-p
  * Bugfix: scripts/functions.
  * Removeperpetual d call to display_osx_hint.
  * Adjusted rvm path setting.
  * Merge pull request #260 from rosenfeld/master.
  * Merge pull request #261 from alec-c4/master.
  * Added hint for OSX users
  * Add example for tweaking Gem options
  * Loading cleanup, adjusting more for zsh.
  * Bugfix: ZSH random declare. Adjusted rvm_user_install with _flag postfix as that is what it is. Corrected usage of rvm_user_install_flag.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Bugfix: do not allow missetting of rvm pretty print flag to blow up.
  * Merged pull request #258 from pweldon/fix_config_user_mv.
  * Ensure aptitude is installed.
  * fix logic for moving config/user -> user/db
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * --no-same-owner is back!!! :)
  * Merged pull request #256 from ConradIrwin/sha1-simplification.
  * Merged pull request #257 from utkarshkukreti/patch-1.
  * Add newline after the error message on running `rvm update`.
  * Further simplify SHA1 extraction.
  * Merged pull request #253 from bergalath/master.
  * Merged pull request #254 from pweldon/fix_user_db.
  * Merged pull request #255 from ConradIrwin/master.
  * Tidy up, and comment option setting.
  * Yeah... I see you too zsh...
  * extglobbing fun :)
  * Merge branch 'master' of git.overnothing.com:rvm
  * Ying, meet Yang.
  * Fix user db overrides to use $rvm_user_path/db consistently.
  * Updated ebuild for latest release.

== Release 1.6.5
  * Using `git rev-parse` instead of `git log --no-color -1` to get the last sha1 commit on current branch so we can remove some treatment.
  * Ubuntu sucks arse through a straw.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Merged pull request #251 from ConradIrwin/fix-nonomatch.
  * --no-same-owner thanks to ngan.
  * Merged pull request #252 from kaerast/master.
  * Return on error.
  * Removed duplicated flags, thnk you very much arrix.
  * added missing dependencies for Centos
  * Updated install line in readme, thanks to crankharder for pointing it out.
  * -o...
  * Correct and clarify resetting of zsh options.
  * Updated ebuild for latest release.

== Release 1.6.4
  * Wow... that was a brainfart.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Select if not selected.
  * More cleanup prompted by last pull request.
  * fixed my brain
  * We found you, you little snot
  * Trying to do too many things at once :/
  * Added rvm_rbx_opts to example rvmrc with comments.
  * This part needs more thought.
  * More cleanup.
  * ...
  * ...
  * Merge branch 'master' of git.overnothing.com:rvm
  * Syntactical Cleanup.
  * Added RBXOPT to environment file recording. Cleaned up environment files and code some.
  * Defaut RBXOPT to -Xrbc.db and -Xagent.start, overrides by setting rvm_rbx_opt in rvmrc.
  * Merge branch 'add_jruby_161_to_known' of https://github.com/sferik/rvm into sferik-add_jruby_161_to_known
  * Missed a q.
  * Add JRuby 1.6.1 to the list of known rubies
  * Merge branch 'fix-install-errors' of https://github.com/chrislwade/rvm into chrislwade-fix-install-errors
  * Default to Jruby-1.6.1
  * Fix typos.
  * Fix errors reported during install.
  * Updated ebuild for latest release.
  * People define "stable" by version numbers, so here I give them another #daft.
  * Added rvm-exec to binscripts installation thanks to arrix.
  * Removed eval from end of rvm-exec.
  * Stick with builtin.
  * Some cleanup.
  * Merge branch 'issues/fix-missing-escape' of https://github.com/meineerde/rvm into meineerde-issues/fix-missing-escape
  * Merge branch 'MagLev-25716' of https://github.com/MagLev/rvm into MagLev-MagLev-25716
  * rvm-installer: fix typo in "--version latest" switch
  * Added rvm-exec as per suggestion by Arrix Zhou.
  * Updated to MagLev-25716
  * Fix another typo
  * Fix missing escape
  * Slight cleanup of new function.
  * Feature: rvm gemset search <gem name> strings
  * Feature: rvm gemset search <gemname>
  * Updated ebuild for latest release.

== Release 1.6.2
  * Adjusted ps1_titlebar as recommended by @chrislwade.
  * Merge branch 'MagLev-25681' of https://github.com/MagLev/rvm into MagLev-MagLev-25681
  * F'n Solaris.
  * already gone!
  * Bugfix: rvm_make_flags_flag
  * Adjusted ps1_titlebar
  * Updated to MagLev-25681
  * Merge branch 'master' of https://github.com/skaes/rvm into skaes-master
  * Take rubygems to 1.6.2 until I can complete the new feature.
  * Fixes bug with calling shopt with ZSH
  * run autoconf if the configure script is older than configure.in
  * Updated ebuild for latest release.

== Release 1.6.1
  * Merge branch 'master' of https://github.com/MagLev/rvm into MagLev-master
  * Merge branch 'ps1_titlebar' of https://github.com/thecatwasnot/rvm into thecatwasnot-ps1_titlebar
  * Merge branch 'codegnome/issue-001' of https://github.com/CodeGnome/rvm into CodeGnome-codegnome/issue-001
  * Merge branch 'codegnome/issue-002' of https://github.com/CodeGnome/rvm into CodeGnome-codegnome/issue-002
  * Defaulting Rubygems version to 1.4.2 based on Evan Phoenix's recommendation.

== Release MagLev-25665
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Updated ebuild for latest release.

== Release 1.6.0 - https only.
  * https AAAAARRRRRGGGGGGHHHHHHHHHHHHHHH
  * __rvm_ask_to_trust(): Aligned 'yes or no' prompt.
  * Better user messages for __rvm_ask_to_trust().
  * Bumped minor version for HEAD.
  * Updated ebuild for latest release.

== Release 1.5.4
  * rvm use 1.2.3 => rbx-1.2.3
  * Ensure extglob is on for r()
  * Updated ebuild for latest release.

== Release 1.5.3
  * Adding titlebar back for xterm in contrib/ps1_functions
  * Altered new git status ps1 feature to minimize external calls.
  * Merge branch 'git_status' of https://github.com/carlosgaldino/rvm into carlosgaldino-git_status
  * Update to MagLev-25646
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: adjusted printf.
  * Adjusted rm_rf
  * nn
  * Fixed regression in 'require'
  * Update to MagLev-25568. Fixes SEGV in MagLev FFI code on Linux
  * show git status
  * Removed extra escape.
  * Updated branching logic thanks to prompting by hiroshi.
  * Merge branch 'fix_branch_select_patterns' of https://github.com/hiroshi/rvm into hiroshi-fix_branch_select_patterns
  * Fix patterns for $(git branch)
  * Merge branch 'master' of https://github.com/wayneeseguin/rvm into macruby_repo_url_github
  * Changed macruby_repo_url to github
  * Merge branch 'master' of https://github.com/ashgti/rvm into ashgti-master
  * Bugfix: call gemset_import in import(), thanks to hedge-hog.
  * Update the ps1_set to escape all of the coloring parts so you can use a separator that is not a new line and not mess up your prompt. See contrib/ps1_functions for more detail.
  * Create and add $rvm_bin_path if necessary
  * Removed extra fi from removed test.
  * Alter calculation of user_install detection.
  * Go through full RVM path initialization in rvm-shell.
  * Merge branch 'untar-ownership' of https://github.com/meineerde/rvm into meineerde-untar-ownership
  * Merge branch 'cleanup_192_pre' of https://github.com/sferik/rvm into sferik-cleanup_192_pre
  * Remove all 1.9.2 pre-releases now that 1.9.2 is final and stable
  * Add -o parameter to all tar extractions to not use existing users and groups when running as root
  * Set $rvm_prefix to actually allow to override the target $rvm_path
  * Allow to actually set an install path other than /usr/local/rvm
  * Add missing shift to allow '--version latest'
  * if exec is called bypass loading libs.
  * Merge https://github.com/arunagw/rvm into arunagw-56b6e97
  * Merge branch 'master' of https://github.com/goncalossilva/rvm into goncalossilva-master
  * Sanity check for the case we are not in a git branch.
  * Merge remote-tracking branch 'upstream/master'
  * Initialize the variables to make sure they are set.
  * Updated ruby186gc for the latest patchlevels. RVM applies patches with -p1, changed patch headings accordingly.
  * added the "ruby186gc" and "ruby187gc" patches
  * Bugfix: remove symlink if it exists.
  * Updated ps1_functions based on discussion with @0x44
  * Fixed gems to gemset
  * Only chown as root.
  * Bugfix: if the hooks files are the same, only run once.
  * More replacement of 'gems" to "gemset"
  * Replacing gems to gemset in test/unit/gemset_test
  * Modified PS4 again.
  * Test for jruby 1.6.0. Default is jruby-1.6.0
  * added working gcdata patch for mri 1.9.2-p180
  * removed non-functional 1.9.3 gcdata patch
  * Updated PS4 to a more readable version.
  * s/exec/eval/:(
  * I am so insanely daft that I make my pet rock look smart :/
  * Adjusting rvmsudo for debugging.
  * Bugfix: Globbing now works properly in zsh.
  * Bugfix: Preserve arguments to rvmsudo.
  * Bugfix: Keep bin path default scripts in sync. Copy instead of symlink.
  * Bugfix: account for multiple digits and up to three.
  * LOFL
  * Adjusted binscripts methods.
  * Bugfix: version detecting for macruby.
  * Adjust for possibility that path is nil?
  * Adjust cap integration for the removal of system-wide.
  * Updated ebuild for latest release.

== Release 1.5.2
  * Ensure etc_profile_file is assigned.
  * Empty check.
  * Missed gems, environments and wrappers.
  * Ensure rvm path dirs exist.
  * Explicit instead of implicit.
  * vra tyop.
  * Rebuild instead of migrate.
  * Close if, silly!
  * s/rvm_selfcontained/rvm_user_install/g
  * More work on profiles.
  * tyop
  * Are we there yet?
  * Automatic user profile setup, Yehuda might yell at me for putting this back ;)
  * Always call setup_rvmrc
  * Improved default rvmrc logic.
  * Respect --path.
  * More fine tweaking.
  * New tactic, only load the associated rvmrc file :)
  * Forcable AND direct!
  * be more direct with setting rvm_path.
  * dassinine - verb - daft and assinine
  * Ahhh it is the token!
  * Allow for rvm-installer x.y.z
  * chmod +x !
  * Determining install path comes first.
  * More work on the installer.
  * Turn on extended globbing.
  * Added new rvm-installer script which combines all functionality of the install-latest install-head and get API.
  * Merge branch 'master' of https://github.com/nerdyc/rvm into nerdyc-master
  * profile.d scripts must be executable.
  * LOL!
  * Working on better profile.d logic.
  * Update rvm ruby selector script to support MacRuby 0.10.
  * .sh :(, thanks bradland !
  * Symlink to prefix path bin, not hardcoded to /usr/local/bin
  * Use /etc/profile.d if it exists, otherwise fall back on /etc/profile.
  * Bugfix: I was a bit overzealous when escaping things :)
  * Use the rubygems API as part of manage.
  * Give the user more information during root installation.
  * Merge branch 'master' of https://github.com/zendesk/rvm into zendesk-master
  * Loading rvmrc fits better in install_setup.

== Release 1.5.1 - rvmrc files are now respected during installs.
  * Respect main rvmrc files.

== Release 1.5.0, anything less is UNSUPPORTED :)
  * Sneeky buggars!
  * Updated update head script.
  * FI fi fo fum!
  * Fun with function names, w00t!
  * So how about we actually append to the file, yes? :)
  * What is in a name?
  * Keep on drillin!
  * Move parse args for clarity.
  * More root canal work.
  * RVM built in installer now handles root installation.

== Release 1.3.2
  * MacRuby 0.10, w00t!
  * Fixed an insanely daft bug.

== Release 1.3.1
  * Fuck you system wide, fuck you.
  * Explicitly do not load rvm.
  * Determine paths separately from loading RVM.
  * Use printf, rvm_error has not yet been loaded yet at this point.
  * Lock and load.
  * fixing rvm get x.y.z
  * Merge branch 'purple-directory' of https://github.com/carlosgaldino/rvm into carlosgaldino-purple-directory
  * Merge branch 'master' of https://github.com/zendesk/rvm into zendesk-master
  * Refactored Install script, it is now much more readable and maintainable.
  * turn off die on error in tmp cleanup trap for shell scripts that enable set -e
  * Missed a spot :/

== Release 1.3.0
  * Switching to a far superior rubygems download url, w00t!!! Thanks kotique!
  * directory is now purple
  * Escape as we do not mean a unicode sequence :)
  * Added contrib to installer.
  * Added ps1_functions to contrib/
  * More trailing slash guards.
  * Account for odd trailing slashes in install script.
  * Remove i386 CPU_TYPE check since new macs return x86_64 Update to version 25506
  * Switched from external calls to using $UID as suggested by methods.
  * Finishing touches for kiji interpreter thanks to initiative by Blue Box Group.
  * Merge branch 'master' of https://github.com/blueboxgroup/rvm into bbg
  * Merge branch 'master' of https://github.com/yura/rvm into yura-master
  * Merge branch 'master' of https://github.com/erikh/rvm into erikh-master
  * Completely removed rvm_interactive_flag, checking directly each time as per recommendation by e2 for zsh.
  * Autodetect rvm_interactive_flag every time
  * Found a few more places...
  * First flushout to add kiji.
  * Fix ri generation
  * don't need to emerge libxml since it's ruby package in gentoo and required ruby 1.8.7 to be emerged

== Release 1.2.9
  * JRuby 1.6.0 is now default.
  * Added rbx-1.2.3
  * Update to MagLev-25439. Seaside works again.
  * Added a project specific hook check.
  * Bugfix: hooks :)
  * Default to user install.
  * Rubygems 1.6.2.
  * Bugfix: Ensure we are in the correct directory during git operations for macruby-head
  * 1.2.8
  * JRuby 1.6.0.RC3
  * Added default value for rvm_path.
  * Merge branch 'master' of https://github.com/anl/rvm into anl-master
  * Fix zsh completion
  * correcting the man files installation locations
  * ignoring .DS_Store files
  * Merge branch 'mkdir_usr_local_lib' of https://github.com/hiroshi/rvm into hiroshi-mkdir_usr_local_lib
  * Merge branch 'master' of https://github.com/re5et/rvm into re5et-master
  * packages script was broken, typo fixed.
  * in case of missing /usr/local/lib directory
  * Updated docs for get.
  * Added rvm get master which does the same as rvm get head for sensitive people. Moved packaging script functions into functions dir.
  * Updated MagLev to 25375 after fixing C-extension problems
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Added RubyGems 1.6.1 URL and md5.
  * Update to MagLev 25370
  * Remove hard-coded /usr/local.
  * More progress on expanding the rails_routes script, r() also.
  * Added scripts/extras.
  * Moved rails CLI helper functions script from contrib to scripts/extras.
  * Added rails_routes to rails helper function r() script.
  * Added screen test when sourcing rvm .
  * Bugfix: zsh cd loading.
  * Remove warning from gemset copy.
  * Added a comment.
  * More cleanup in gemsets.
  * Ensure that rvm_gemset_name is unset for gemset copy.
  * Unset gemset name.
  * Respect PAGER while still protecting from .rvmrc based attacks.
  * ZSH auto_name_dirs feature is troublesome :)
  * Added comments and a sanity check to the trap.
  * Shut your trap!
  * Merge branch 'disk_usage_symlink' of https://github.com/ilikepi/rvm into ilikepi-disk_usage_symlink
  * fixed gemset completion function .
  * Explicit match.
  * Directory check on ruby gem home.
  * Set current to 1.6.0
  * Added md5 and URL for RubyGems 1.6.0.
  * Adjust __rvm_fetch_ruby based on suggestions by brixen.
  * Add trailing '/' so disk-usage can handle symlinks
  * --disable-install-doc flag set by default.
  * Merge branch 'master' of https://github.com/pedz/rvm into pedz-master
  * Load __rvm_db as part of base.
  * Bugfix: The patchlevel tried to run away!!!
  * Remove GEM_HOME and GEM_PATH from initialize export.
  * Bugfix: load rvm reset where used.
  * Merged back in all my previous changes
  * Export rvm_ruby_repo_branch
  * Silence silly messages.
  * Removed no longer necessary n* case from selector.
  * Install 1.8.7 dep with a clean env
  * Ruby name now propigates in selector.
  * te hee!!! You see nothing!
  * Remove empty extract target directory.
  * Feature: Named rubies can now be any alphanumeric sequence at the end of the ruby string, no more -n necessary. In fact -n will be removed "soon".
  * Feature: -n/--name [name] to name a ruby, in addition to -n in ruby string.
  * Removed leftover function call.
  * Cleanup setup & initialize some more.
  * Take that ye variable leech!
  * Bugfix: keep exports in cd until the last second.
  * Ensuring all vars are set for project rvmrc loading.
  * Reorganization and cleanup. scripts/utility => scripts/functions/*
  * Missed an exit.
  * Added help for install
  * Bugfix: hard exit when error occurs during ruby install.
  * Bugfix: Proper globbing for rvm gemset import.
  * Seperate returned list from rubies list.
  * Check for matches first.
  * Added ncurses-dev to ruby dependencies on apt based systems.
  * Alter __rvm_18_compat_ruby to explicitely exclude macruby,goruby,jruby,anything not matching.
  * Added ~amd64 to KEYWORDS in ebuild templates.
  * Missed a flag for unset, simplified match()
  * Missed a variable for env cleanup.
  * Type based removal.
  * Removed a bit of redundancy.
  * Adjusted installer script sourcing.
  * Install check should not be quoted.
  * Only install 1.3.7 for Ruby 1.8.6.
  * Be far more precise when copying install files and directories over.
  * Merge branch 'rbx-1.2.2' of https://github.com/sferik/rvm into sferik-rbx-1.2.2
  * Add rubygems 1.5.3
  * Add rubinius 1.2.2
  * Cleanup unused checksums
  * Merge branch 'master' of git.overnothing.com:rvm
  * Rename $path to $target in __rvm_rm_rf
  * Add in a patch level for rubinius 1.2.2
  * Bugfix: stupididity.
  * Rebase when pulling.
  * Tyop.
  * Missed a ;
  * All rm -rf calls now use a _slightly_ safer __rvm_rm_rf with some sanity checks in place. Thanks Sven!
  * Adding some sanity checks around rms
  * Added sanity check to rm for tmp cleanup, suggested by sven schwyn.
  * Merge branch 'master' of https://github.com/caius/rvm
  * Bugfix: Manage script variable truncation.
  * Stop ZSH warning about unmatched globs by setting an option.
  * Revert "Supress a warning when cleaning up ./tmp under ZSH"
  * Merge branch 'master' of https://github.com/ferrous26/rvm
  * Supress a warning when cleaning up ./tmp under ZSH
  * Began revising get to be able to specify a specific revision.
  * cd will need some work to be configurable for scripts.
  * MacRuby latest release is now version 0.9
  * More cleanup.
  * Bugfix: missing variable name. Thanks tilthouse.
  * arg*v!
  * rvm tmp path.
  * Properly cleanse rvm environment.
  * Ignore .rvmrc :)
  * Add pkg/ to gitignore.
  * Added functions.
  * Rollback cd.
  * Wrappers and environments.
  * Temp path configurable.
  * Cleanup, aisle _
  * Config path configurable.
  * gemsets & hooks.
  * rvm_scripts_path configuration variables.
  * Added in rvm_archives_path config.
  * Missed a "
  * Initialize variables.
  * Where did they go?!
  * Consistently use rvm_rubies_path for ruby installation path setting.
  * Merge branch 'master' of https://github.com/MagLev/rvm into MagLev-master
  * Removed VERSION.yml symlink.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Added comment to leave the eval.
  * Call__rvm_rvmrc_tools for escaping
  * Bump head version to 1.2.8
  * Updated manifest.
  * Merge branch 'master' of git.overnothing.com:rvm
  * Updated manifest for only the gem release files.
  * Make scripts/migrate deal correctly with the base gemset
  * use -eq insetad of = for an integer test
  * New release - MagLev 25239
  * Merge branch 'system-installer-rev-fix' of https://github.com/fnichol/rvm into fnichol-system-installer-rev-fix
  * Fetch more history in install-system-wide when called with --revision.
  * Use correct gemset file name.
  * Merge branch 'gemsets-import' of https://github.com/docwhat/rvm into docwhat-gemsets-import
  * Merge branch 'master' of https://github.com/ferrous26/rvm into ferrous26-master
  * Merge branch 'master' of https://github.com/sferik/rvm into sferik-master
  * Merge branch 'master' of https://github.com/sikachu/rvm into sikachu-master
  * Merge branch 'master' of https://github.com/xing/rvm into xing-master
  * Merge branch 'master' of https://github.com/wt/rvm into wt-master
  * Update for MagLev 23515
  * REE 2011.03 now default for ree.
  * fixed typo that prevents cloning ruby via https
  * Update installation procedure in README
  * Swap find args so that find doesn't complain.
  * Unset rvm_ruby_name when cleaning up.
  * MacRuby nightly builds are now on version 0.10
  * Add 1.9.1-p431 as default 1.9.1
  * Non-awk way to import configuration files for gems.
  * No grep for you sed I!
  * Act on Christian's suggestion to use new current_gemset function in info script.
  * Added Christian's function to utility.
  * Formatting.
  * 'rvm gemset list' now has a '=>' for the currently used gemset
  * Updated usage and help.
  * SANITYFIX: rvm upgrade [source] [destination]
  * added full path to usermod
  * Fix bug where "rvm gemdir" was throwing an "unknown action" error
  * New ree release, fixed a tyop.
  * Use a case for argument parsing in alias.
  * Bugfix: rvm help get works as intended now.
  * MagLev 25289.
  * Annotations and consolidation.
  * Removed update added get to usage output.
  * Merge branch 'master' of https://github.com/spastorino/rvm into spastorino-master
  * Add 1.9.2-p180
  * Add 1.8.6-p420
  * Fix to add rvm/environment/wrapper to RVM::Environment.
  * Bugfix: allow 'rvm @gemsetname' to switch gemsets
  * Bugfix: test for ree version #
  * Added extra arg check.
  * Default action to use.
  * Moved usage from flags section into command section.
  * alnum fool!
  * Refactored argument parsing for more efficiency / less checking to reach end goal.
  * Reordered ruby check.
  * Reordered checks in cli parse args
  * Removed old matcher case.
  * sgr0 is safer than setaf 9.
  * Altered logging function definitions.
  * Bugfix: Adjust pattern match, thanks to thomasfedb for pointing this out.
  * 1.8.7-p334 is now default.
  * bye bye now!
  * Pulled logging internal.
  * Squeaked even more performance into the selector straight shell builtin case.
  * Performance improvement centered around the selector.
  * Merge branch 'speed-up-cd-hook' of https://github.com/tastapod/rvm into tastapod-speed-up-cd-hook
  * Replaced call to grep with case match to speed things up. Replaced for loop with 'env|while read' to protect env vars with spaces.
  * Fix call to unset causing the real result of rvmrc trustworthiness to be lost.
  * Minor version bump.
  * Added an ERROR message with an exit when JAVA 1.3 / 1.4 detected for jruby install
  * Added warning when java version is old when installing JRuby.
  * Merge branch 'master' of https://github.com/fnichol/rvm
  * Fixed syntax.
  * Merge branch 'master' of https://github.com/victorluft/rvm into victorluft-master
  * Merge branch 'master' of https://github.com/cr0t/rvm into cr0t-master
  * Extract install dir from rbconfig.
  * Account for Rubinius when altering rubygems versions.
  * Tyop fix.
  * Added Rubinius 1.2.1 to known list.
  * Allow Rubinius to change rubygems versions.
  * Fixed rvm_ree_options autosetter to --no-tcmalloc on Darwin systems
  * Added emerge line for notes.
  * Bugfix: when using --ree-options be sure to use the parameters passed in. Thanks to dmilith for catching this.
  * Update group modification support in install-system-wide for SuSE.
  * WTF??? Seriously? A new Repo? Save a tree, use branches!
  * Default ree is now ree-1.8.7-2011.01.
  * Rubygems 1.5.2 is now default.
  * Removed old maglev md5 sums
  * Maglev version 25223 is now default
  * Added jruby-1.6.0.RC2 to known list.
  * Setting a default ruby now creates ~/.rvm/bin/<binary> for each binary in the default wrapper directory.
  * Rubygems 1.5.1 is now default.
  * Fix gemset copy to be able to use non-complete gemset name. (I.E. @gemset or 1.9.2@gemset instead of ruby-1.9.2-p136@gemset)
  * Fix API method typo (gemset_intial -> gemset_initial).
  * Merge branch 'master' of https://github.com/aef/rvm into aef-master
  * Reverted JRuby 1.6.0.RC1 to be the default choice for JRuby
  * Merge branch 'master' of https://github.com/Innova/rvm into Innova-master
  * Merge branch 'rvmrc_fixes' of https://github.com/tpope/rvm into tpope-rvmrc_fixes
  * README.
  * Removed unsetting of rvm_path and rvm_prefix since these are required in several scenarios to be pre-set.
  * Separated out RVM version from RVM API version.
  * Added a version file back in.
  * Added files back into API gem.
  * Damn I suck... no more lisp and ruby at the same time. brain gone
  * Oops! Needed to deal with VERSION.yml going away
  * Added jruby-1.6.0.RC1 to the known rubies
  * Fixed licence annotation at the end of README thanks to zenspider.
  * Moved from jeweler to hoe (mostly... needs check my wayneeseguin)
  * Moved pkg to meta
  * Fixed variable initialization problems in scripts/rvm
  * MagLev 25186
  * Fixed typo in utility script
  * Fix typo
  * Prevent false matches on gems in .rvmrc bundling
  * Clean up run-on sentences in .rvmrc
  * Don't output bundle binary path from .rvmrc
  * Bugfix: odd tyop in help script.
  * Reworded rubygems line in README.
  * Feature: rvm RTFM
  * Bugfix: rvm gemset copy now works as intended.
  * Create destination gemset if it does not exist.
  * Removed contentious comment.
  * Updated ebuild for latest release.

== Release 1.2.6
  * Feature: rvm rubygems remove.
  * Removed obsoltete items from README.
  * Bugfix: correct path to log.
  * If revision is "head" then recenter to "master" for a git fetch.
  * Use builtin rubygems command to update to current during manage install.
  * Updated ebuild for latest release.

== Release 1.2.5
  * Added Rubygems 1.5.0 md5
  * Rubygems 1.5.0 is 1.9 compatible, w00t!!!
  * How the Eff did that happen???
  * Its SunOS not Solaris-x86
  * Bugfix: Default rvm_promptless to 0.
  * Merge branch 'solaris' of https://github.com/kylef/rvm into kylef-solaris
  * Merge branch 'solaris-install' of https://github.com/kylef/rvm into kylef-solaris-install
  * jruby-head needs ant and a jdk to install (updated for Ubuntu).
  * Bootstrap script should pass --default flag, good catch Sutto.
  * RVM uses the Apache Licence v2.0.
  * Added "ls" as an alis for the list command, ala pik.
  * Make install-system-wide support SunOS
  * Properly detect if its a 64bit Solaris-x86 machine or not
  * always pull from remote repo when installing from head
  * Bugfix: tyop, thanks to rsim for pointing it out.
  * Added info message when trying http url.
  * Fixing macruby-head bug.
  * Create destination during a copy.
  * Merge branch 'master' of https://github.com/timfel/rvm into timfel-master
  * Slight refactoring in rvm-prompt.
  * Allow to use characters in prompt like virtualenv for python
  * Bugfix: logic error, thanks to lfalcao for pointing this out.
  * Fixed a tyop thanks to telemachus.
  * Added bootstrap_rails_environment contrib script.
  * force re-setting of GemStone url, otherwise downloads won't work, if the URL has already been set in the env
  * Updated ebuild for latest release.

== Release 1.2.4
  * WTSyntax?
  * Updated ebuild for latest release.

== Release 1.2.3
  * Added libxslt/libyaml to usage output.
  * Merge branch 'master' of https://github.com/sunteya/rvm into sunteya-master
  * Bugfix: tyop.
  * Added libyaml package.
  * Maglev 25051 is now default.
  * The 'rvm remove' will re-delete environments and binaries
  * Merge branch 'base-typo' of https://github.com/jcf/rvm into jcf-base-typo
  * Merge branch 'rvm-current' of https://github.com/jcf/rvm into jcf-rvm-current
  * Second patch by lordzork + slight syntax cleanup twards the project standard.
  * Applied patch by lordzork.
  * Removed =~ usage for older shells, thanks to cosine.
  * Correct a typo in a comment within scripts/base
  * rvm current
  * Default rvm_path and rvm_prefix to exported environment variables then empty string. Thanks to agreif for pointing out the issue.
  * Updated ebuild for latest release.
  * Defaulting RubyGems to 1.4.2 for allowed interpreters (MRI 1.8.X).
  * Doublejump!
  * Also escape forward slashes for awk match.
  * Reorder our escape sequence :)
  * Awww.. c'mon ... you saw them too?!
  * But I *like* backslashes :(
  * It is amazing how much one lil dot can affect things :)
  * Adjusted trust check logic.
  * Adjust for when USER is not set.
  * Use escape when checking trustworthiness
  * Version bump to 1.2.2
  * Adding a packaged version of rvm and a new rvm-install script which uses the version packaged in the gem. Thanks to vkushner for the conversation :)
  * Missed a file.
  * Feature: use a user directory in order to store user settings instead of the config/ dir. This also fixes the "disappearing rvmrc" bug.
  * Support JRuby's .RCX kinkyness.
  * Added escape flag for db.
  * Escaping keys in the db :)
  * Added rvm_always_trust_rvmrc_flag to examples.
  * Only for ruby interpreter use svn like branch calculation.
  * Applying zenspider's patch
  * Account for possibility that rvm_path is not set.
  * Trust a .rvmrc file if rvm_always_trust_rvmrc=1 is set in ~/.rvmrc or /etc/rvmrc regardless of contents if it is trusted once. Thanks to yonahw for this!
  * Remove file before writing to it in gemset export.

== Release 1.2.1
  * Altering loading of override_gem.
  * Clear all traps upon successful teardown. Call rvm teardown on trap.
  * Merge branch 'master' of https://github.com/adammck/rvm into adammck
  * Added a check to ensure /etc/rvmrc exists before sourcing it, thanks to pedz for the heads up.
  * Bugfix: account for unset variables, thanks to zenspider for pointing it out.
  * add rvmrc test.
  * fix trailing space bug, and improve tests.
  * add minimal unit tests for 'rvm [un]export'.
  * add minimal docs for [un]export.
  * add 'rvm export' and 'rvm unexport' actions.
  * Make sure \n is literally printed in the .rvmrc file, as opposed to being interpolated
  * Bugfix: escape quotes inside .rvmrc template.
  * Updated ebuild for latest release.

== Release 1.2.0
  * Bugfix: ensure that .rvmrc files are output exactly as they are ignoring escape sequences.
  * Updated ebuild for latest release.

== Release 1.1.13
  * Fixed a daft tyop, thanks to El_Picador for pointing this out.
  * Be more verbose by default for users.
  * Increased verbosity and clarity of the .rvmrc file, also made it more DRY.
  * Revert to printf since log has been removed. Thanks to khasse for bringing this up
  * Bugfix: Nono RVM, Bad touch!
  * Updated ebuild for latest release.

== Release 1.1.12
  * Bugfix: tyop with syntax.
  * Ruby repository uses 'trunk' as 'master'
  * Install -head MRI Rubies via github.
  * Removed legacy rvm-install
  * Bugfix: Ensure archives directory exists for latest.
  * Removed configure env setup from manage, leaving for libraries
  * Added libc6-dev to aptitude installation notes.
  * Updated ebuild for latest release.

== Release 1.1.11
  * Added *.rbc to gitignore.
  * Comment out archflags for now.
  * Updated rvm-get-latest
  * Bugfix: rvm get latest, variable correction.
  * Updated ebuild for latest release.

== Release 1.1.10
  * Merge branch 'archflags'
  * Swithed install head script to use https, install latest script now checks md5.
  * Archflags working on packages, not quite yet on rubies.
  * Added some varaibles to cleanup.
  * Removed extra trailing slashes
  * Updated ebuild for latest release.

== Release 1.1.9
  * Rubygems 1.4.1
  * Added newline as requested by daniely.
  * Merge branch 'master' of git.overnothing.com:rvm
  * Do not unconditionally call project rvmrc when cli is loaded, this is taken care of when RVM is loaded in scripts/rvm
  * Add in zlib-gc-fix for 1.8.7 and ree, Fixing issues with bundler installing gems.
  * Updated ebuild for latest release.
  * Adjusted rvm notes for JRuby on aptitude hosts.

== Release 1.1.8
  * Bugfix: rvm remove --gems X now uses full paths to avoid any possible CWD issues. Thanks to agrimm for bringing this to our attention.
  * Bugfix: unbound variable in cli.
  * Use rvm_promptless for the rvm-auto-ruby and the like to avoid hangs in things like TextMate
  * libruby osx arch patch for 1.9.1 and 1.9.2
  * Added openssl-devel to yum distro notes.
  * Updated ebuild for latest release.

== Release 1.1.7
  * ruby-1.9.2-p136
  * ruby-1.8.7-p330
  * MagLev 24924
  * Merge branch 'fix_test_suite' of https://github.com/txus/rvm into txus-fix_test_suite
  * Fix: test suite refers to unknown dir
  * Fix typo on rbx-1.2.0
  * rbx-1.2.0-20101221
  * Missed 2 sed's, thanks to gabebw for pointing this out.
  * Merging in patch by iLikePi.
  * Practice safe sed :)
  * Merge branch 'master' of https://github.com/cdunn2001/rvm into cdunn2001-master
  * Merge branch 'fix-191-version' of https://github.com/gabebw/rvm into gabebw-fix-191-version
  * Zsh completion of gemsets trailing rubies (#84)
  * What, you mean you actually want to compile something???
  * config/known now shows correct ruby-1.9.1-p378
  * Append to file, again thanks for the heads up cdunn2001.
  * Change over-write to append; same as previous change by wayne, different line.
  * Append to file, thanks for the heads up cdunn2001.
  * Updated ebuild for latest release.

== Release 1.1.6
  * Updated post intsall message for the gem releases.
  * Solaris, why can you not play nice with others???
  * Altered the way PATH is cleaned to get things working on Solaris.
  * Make implode take into account other items including wrappers
  * Bugfix: Macruby gem command now respects gemsets.
  * MagLev 24864
  * standardise the display of known rubies and their defaults eg.   macruby[-0.8] rather than   macruby-[0.8]
  * Updated ebuild for latest release.

== Release 1.1.5
  * MacRuby 0.8 is now default.
  * Added informational output when --static is used.
  * Bugfix: Allow rvm_static_flag to pass through.
  * Feature: --static for statically built MRI Rubies. Removed RVM installation from RVM API gem.
  * Switched to https.
  * Added line numbers to the default irbrc prompt
  * Temporary fix for the project rvmrc bug w/ path-identifier
  * Escape aliases in the shell wrapper, correctly export the shell variables in environment.rb
  * Escape a grep in selector.
  * Tweaked version check / exporting rvm_version.
  * Removed unused extra variable.
  * Updated ebuild for latest release.

== Release 1.1.4
  * Feature: 'rvm gemset list_all'. Thanks to jedmtnman.
  * Merge branch 'master' of https://github.com/blueboxgroup/rvm into blueboxgroup-master
  * Patch to resolve issues experienced with a missing rvm_path command.
  * Handle md5 in fetch on OpenBSD. Thanks to Andrew Gwozdz
  * Bugfix: When NOT root :) thanks jonathonstorer.
  * Switch from whoami to id for POSIX compatibility as suggested by rockyb.
  * gem install jruby-launcher after installing any jruby.
  * Added jruby-launcher to JRubys global gemset.
  * Further quoting fixes.
  * Bugfix: Properly quote when -e is called.
  * Added libxslt to the recommended dependencies list, thanks laomao!.
  * Bugfix: Clear defaults and delete alias when system is set as default. Do not output the alias deletion (twice even!) Thanks to dreamcat4 for this.
  * rake install macruby via rvmsudo.
  * Updated ebuild for latest release.

== Release 1.1.3
  * Merged in a tweaked version of robotarmy's OPenBSD patch.
  * JRuby 1.5.6 is now default.
  * Acted upon Dreamcat4's recommendation.
  * Load rvmrc when rvm is sourced.
  * Allow setting of rvm_tmp_path in ~/.rvmrc
  * Updated ebuild for latest release.

== Release 1.1.2
  * Merge branch 'master' of https://github.com/wingrunr21/rvm into wingrunr21-master
  * Merge branch 'darwin_notes_abandon_system_ruby' of https://github.com/billgathen/rvm into billgathen-darwin_notes_abandon_system_ruby
  * rvm install goruby
  * Update system wide installer for Darwin support
  * Bugfix: 'rvm --default system' now works as expected
  * Reset when system is set as default.
  * Allow selecting git branches via --branch when installing a Ruby.
  * Bugfix: setting default now properly creates an alias again. rvm list default also works again.
  * Tyop fix, thanks to nirvdrum.
  * Added rvm_ruby_name to variable unset section thanks to rocky.
  * I usually run rvm interactively logged in as myself, but got a confusing error when I tried to have my webserver running as www-data source it to use in a setup script.  Hopefully this change will make it clearer to anyone trying to do the same thing.
  * Updated ebuild for latest release.

== Release 1.1.1
  * Egg enhancement.
  * Ensure that when using an RVM Ruby BUNDLE_PATH is unset.
  * rvm gemset import output is a bit nicer.
  * Merge error & log files into a single log file.
  * libreadline5 => libreadline6
  * s/git/git-core/ for ubuntu packages.
  * Added libyaml-dev to ruby deps on Ubantos.
  * Added after cd hook to latest zsh.
  * Added before & after do hooks.
  * Added before_install / after_install hooks.
  * Revert "a few more quotes"
  * When installing as user always install to ~/.rvm
  * a few more quotes
  * A quoting we will go!
  * Added notice upon script entry.
  * Yeah... I'm going to pretend that I did not just do that, join me please.
  * Bugfix: rvm install 1.8.7,1.9.2
  * Silence grep for BUNDLE_PATH.
  * Bugfix: only adjust environments files if the directory exists.
  * I *love* it when interpreter authors are highly responsive, go brixen!!!
  * Check for BUNDLE_PATH before replacing.
  * Bugfix: remove the prefix path before configuring for rbx.
  * Bugfix: Remove the destination prefix path for rbx install.
  * Bugfix: Clean BUNDLE_PATH from environments on install.
  * Removed shyouhei/mputs interpreter install as it is no longer necessary or maintained given the official ruby github mirror.
  * Bugfix: Remove destination path when updating from github.
  * Updated ebuild for latest release.

== Release 1.1.0 (aka 1.0.23) discontinues use of BUNDLE_PATH and global gems are now picked up by Bundler (1.0.5+).
  * Updated ebuild for latest release.

== Release 1.0.23. Bundlercats ho!!!
  * No longer use BUNDLE_PATH. Three cheeers for team Bundler! w00t! w00t! w00t!
  * Indicated that rbx-head is default for rbx.
  * Add Rubinius 1.1.1
  * Fix build of macruby-nightly
  * Bugfix: default rvm_cd_complete_flag to 0
  * Changed rvm_trust_rvmrcs to rvm_trust_rvmrcs_flag=1, as it is a flag. Take Note Folks!
  * Updated ebuild for latest release.

== Release 1.0.22 - The quirkey release.
  * Feature: rvm_cd_complete_flag for ~/.rvmrc.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Add bug fix for rvm tools path-identifier (and hence support in passenger).
  * Default rbx version is now head.
  * Bugfix: Detect rvm function load.
  * Bugfix: properly call "less -X" as default PAGER, thanks to lmarburger for the heads up.
  * Bugfix: Working function load test for both sh and bash/zsh.
  * Tyop Fix: it appears that visually rvm and ruby interchange when reading quickly... Thanks again to aspiers.
  * Adjusted wording for more clarity, thanks to aspiers.
  * Bugfix: Allow RVM loading detection to work with sh, thanks to David Black.
  * call less -X to stop the screen from clearing.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Tweaked the nice patch by James Blanding.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * More traditional behavior for './install --help'
  * Another string readability tweak.
  * See the diff, rvm install ree -C --with-readline-dir=$rvm_path/usr,--with-iconv-dir=$rvm_path/usr,--with-zlib-dir=$rvm_path/usr,--with-openssl-dir=$rvm_path/usr was oldskool, now it is rvm install ree --with-readline-dir=$rvm_path/usr --with-iconv-dir=$rvm_path/usr --with-zlib-dir=$rvm_path/usr --with-openssl-dir=$rvm_path/usr
  * bumping jruby to 1.5.5
  * Some cleanup of selector.
  * Bugfix: gemset name persisting after failed use issue. https://gist.github.com/607116 Thanks be to george.
  * Bugfix: "rvm 1.8.7 test.rb" now works as expected, Thanks to Alex Chaffee
  * Merge branch 'master' of git.overnothing.com:rvm
  * Bugfix: do not include /bin in GEM_PATH. Thanks to cube!
  * Bugfix: error when "1.8" or "1.9" is used.
  * Thanks valeri_ufo!
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Addressing the concerns of portsnap.
  * Adjust handling of CDPATH to honor new IFS value
  * Make sure you use the unaliased grep
  * Updated ebuild for latest release.

== Release 1.0.21
  * Bugfix: "rvm install 2.9.2" now fails as expected
  * Fixed possible format string vulnerability.
  * Fixes a problem where tab completion didn't work when a directory in the path contained a space.
  * Updated ebuild for latest release.

== Release 1.0.20
  * Bugfix: remove src dir if it already exists before moving extracted dir over.
  * Bugfix: unset rvm_ruby_package_file as well.
  * Patch by Darcy Laycock <sutto@sutto.net> "Convert to an array correctly."
  * Bugfix: properly return bison check code. Thanks to joukokar for this.
  * Convert to an array correctly
  * Suppose (and not Supose)
  * Added instructions for abandoning Snow Leopard system ruby.
  * Handle /D<Tab> cases so they don't try 'Documents'.
  * Fix cd tab-completion.
  * Added instructions for abandoning Snow Leopard system ruby.
  * Just finish to put comments to better docs
  * Put some comments in info and add comments in the #use method
  * Add some example in list informations about environments
  * The #env_contents should return a array
  * Added some comments in env methods (It's better for rdoc =-)
  * Bugfix: 'rvm rubygems 1.3.7' thanks to Matthew McEachen (mrm_adgrok) w00t!
  * MagLev 24566
  * Stick to the most standard tool for Ruby in RVM default gemsets, users can add their own.
  * Backed out rvm_export_if_set, sorry teleological too big of a performance hit. There must be another way.
  * Enable alias complettion for zsh
  * Fixed: s/rvm update --head/rvm get head/, thanks to Nathan Youngman.
  * Updated update-head script
  * Updated ebuild for latest release.

== Release 1.0.19
  * Added scripts/get.
  * Bugfix: Turn off error tracing when done.
  * Features: 'rvm get latest' and 'rvm get head', Depreciated: 'rvm update' and 'rvm update --head'
  * Tweaking for when USER is undefined.
  * Hardcode location of sysctl on OSX, thanks to shigeya@wide.ad.jp
  * Updated ebuild for latest release.

== Release 1.0.18
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * unsetting RUBYLIB / RUBYOPT thanks to suggestion by khaase
  * SHA should be short not long
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Updated ebuild for latest release.

== Release 1.0.17
  * I believe this is a bug fix
  * Further tweaked fetching user name.
  * Switched user name retrieval to "git config user.name", thanks cypher23
  * re-comment cd completion code.
  * Manually applied patch by teleological. http://github.com/teleological/rvm/commit/21d6083db3fffc5fa92b9ea8814f3f28f7e48c7f
  * Bugfix: unset rvm_head_flag with ruby variables, thanks koraktor.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Bugfix thanks to mbarnett: Fixes an issue where cd completion will fail completely if any directories in CDPATH do not exist.
  * Fixes rvm update problem on zsh.
  * Fix Ubuntu notes.
  * Updated md5 file.
  * Commented out _rvm_cd_complete for now, unsure as to the purpose of it.
  * Bugfix: Account for rvm_ruby_version being empty.
  * Bugfix: properly compute next token for --branch
  * Updated ebuild for latest release.

== Release 0.1.16: The NYC.rb Release.
  * flags should be tested as integers and be sure to account for nil
  * Only trigger loading of rvmrc if in an interactive shell when sourced.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Feature: --branch for use with git head repositories.
  * Moved cd autocompletion so it will really run.
  * More updates for --repo
  * Dumb dumb dumb dumb....
  * Bugfix: we have the first user using --repo :)
  * Tweaked rvm notes a bit more
  * Tweaked rvm notes output for clarity.
  * Added a .nil? guard in case rvm_path is not set in the environment.
  * Fixing rvm update.
  * Updated ebuild for latest release.

== Release 0.1.15
  * Trigger any cd hooks when sourced.
  * Removed rubyforge as a source for rubygems and the latest ruby enterprise.
  * Change git-core to git; git-core now deprecated in Ubuntu repo
  * Fixed a silly tyop, thanks dipnlik.
  * Rescue LoadError explicitely for Readline failure, thanks to Alexey Antipov.
  * MacRuby 0.7.1
  * Bugfix: nonzero exit code when unrecognized command.
  * Allow gemset to pass through the variable clearing.
  * Addressed Yehudas rvm-prompt slowness query.
  * Adjusting order of operations for ruby string calculation.
  * slightly reverted user patch.
  * Removed patches from openssl for now, until someone tells me WTF happened to them.
  * Feature: rvm gemset rename X Y (for currently selected ruby)
  * Getting this to work: rvm my_alias@my_gemset. Previously only e.g. rvm 1.8.7@my_gemset worked.
  * Worked a bit on the integration tests.
  * Maglev 24407.
  * Added notice about re-setting default if user sees the error message.
  * Bugfix: do not blindly chmod +x, thanks egyp7!
  * Blasted formatting issues, thanks for the kick in the arse jacquesc.
  * Updated ebuild for latest release.

== Release 1.0.14
  * Added man/ to gem files.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Merged in patch by deliciousrobots, domo arrigato!!!
  * Clean up.
  * Add a short hand to install all dependencies for ree in appropriate order.
  * Revert "Reamin rvm_ruby_interpreter to show current ruby on rprompt."
  * Ask readline to use ncurses in ~/.rvm/usr
  * Reamin rvm_ruby_interpreter to show current ruby on rprompt.
  * FIX: fail to build readline-5.2 on Snow Leopard, and may be on Leopard
  * FIX: wrong path to patch
  * FIX: missing codes to apply patches
  * FIX: rvm_project_rvmrc_default doesn't work
  * no need for -d on rm, -f ignores non existent
  * no need for -d on mkdir -p: checks that automatically
  * Copied over latest install head script.
  * Reversed the order of git url attempts.
  * MacRuby 0.7 is now default.
  * Updated ebuild for latest release.

== Release 1.0.13
  * Bugfix: postpend not prepend rvm_path for selector for system case.
  * Slightly tweaked conditionally add bin path.
  * Missed a spot with rvm_gems_path.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Updated ebuild for latest release.

== Release 1.0.12
  * grab revision from the right argument
  * fix path bug in wrapper wrap()
  * make is also required by arch
  * Sing along with me now folks, 'I'm a dumbass after all, I'm a dumbass after all, I'm a....'
  * I have been convinced of the readability difference between function declaration styles.
  * Merged in bash cd completion patch by albus522, thanks!
  * Bugfix: account for empty binary list.
  * Bugfix: upgrade, thanks kevwil.
  * Further separate out destination calculation.
  * Removed extra \\
  * Reformatting code.
  * only 1.9+ requires a 1.8 compatible ruby to build.
  * Tweaking gemsets calculation for telemachus.
  * JRuby 1.5.3 is now default.
  * Fix disk usage and cleanup to work again with the newly refactored code. Thanks to tomyum for the patch
  * Fixed a tyop, thanks piclez.
  * Installer will now exit on any unhandled nonzero return status.
  * Bugfix: fixed unbound variables in installer.
  * Bugfix: no more "pretty slash trails"
  * Refactored 'rvm repair gemsets'.
  * Feature: rvm repair gemsets
  * Bugfix: Ensure that gems/@global and gems/*@ no longer appear.
  * Rubinius now defaults to 1.1.0, thanks for the heads up spastorino
  * Bugfix: rvm-prompt when jruby is used.
  * Bugfix: s/--/-/
  * Bugfix: allow bash to list the directories for find to search.
  * Bugfix: Fixed order of parameters for older versions of find in post cd completion code, Thanks for the heads up telemachus.
  * Cleaned up upgrade script thanks to feedback from jatan.
  * Ensure that bin path exists.
  * Whoops, forgot the env!
  * Look ma, I am flexible!
  * Swap command order.
  * Going for the throat.
  * Wrap rvmsudo eval command in quotes.
  * Tweaked wrapper to display usage when no arguments are supplied.
  * Added rvm list ruby_svn_tags to help output.
  * Removed call to regenerate_wrappers, thanks jmhodges.
  * Bugfix: rvm 1.9.2 gemset create testes now works as expectd, thanks cjbottaro!
  * Updated ebuild for latest release.

== Release 1.0.11
  * Added rvm_path/bin to mkdir list for install.
  * Added NOTE to --passenger flag about Passenger 3.
  * NEVER use backticks.
  * use $PAGER
  * Tab-complete through a chain of dirs works as normal
  * Maintain CDPATH tab-completion with RVM's cd
  * Tweaked rvm repair output.
  * Merged in wrapper regeneration into repair.
  * Attempting to debug the wrapper regeneration.
  * Use full path for wrappers :/. This means that after rsync users will have to do an "rvm repair all".
  * Bugfix: rvm gemset copy X Y now works properly (tyop)
  * Set errtrace for installer at the top.
  * Default rvm_ruby_string to empty string.
  * adjusted wrappers regeneration
  * Account for possibility of no rvm_ruby_string in __rvm_run.
  * Some cleanup on installer, now runs under shell options noclobber, nounset, errtrace. Now respects --trace as part of args parsing.
  * Add gemset support to aliases
  * Fix bug with sourcing items in alias
  * Forgot the version number, lol!
  * Updated ebuild for latest release.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Applied patch from Christopher Roach, Thanks!
  * Outline case statements. Removed another 'echo' statement.
  * Removed echo statement for os_type.
  * Updated install-system-wide script with support for FreeBSD (tested with FreeBSD 8.1).
  * Merge branch 'master' of git.overnothing.com:rvm
  * Simple refactoring
  * Add rvm_ruby_api env variable to make detection in .rvmrc files possible
  * Hook wrapper regeneration into the upgrade process
  * Add wrappers to repair
  * List fixes, regenerate for gemsets
  * Add utility to regenerate all wrappers
  * Improved shell escaping for env
  * Implement a more advanced method of detecting the default rvm_path in the ruby library
  * Added rvm_path to env file exports.
  * Bugfix: --trace actually produces a trace once again. Bugfix: automatically regenerate wrapper scripts if missing.
  * Adjusted rbx compile to use the wrapper script for the 18 compatible ruby.
  * Defaulting rvm_ignore_rvmrc, thanks Cicloid.
  * Bugfix: Testing for directory in .rvmrc, thanks bjencks!
  * Initialize rvm_ruby_interpreter to first part of rvm_ruby_string if not set when entering the selector.
  * More cleanup.
  * Bugfix: rvm 1.8.7,1.9.2 gem install X
  * Bugfix: escape any / characters in in the match regex.
  * Bugfix: symlinks for default, etc now get created again!
  * Some more cleanup.
  * Bugfix: rvm 1.8.7,1.9.2 exec ruby -v
  * PIBRQBAS
  * Replaced .nitems with .compact.length
  * Bugfix: cleanup tracing on exit.
  * Bugfix: rvm 1.8.7 exec ls
  * Do not load completion if readline failed.
  * Bugfix: move maxhistsize within the scope of Kernel::at_exit
  * fix % to %% substitution in log script for older bash
  * use an alternate method to save irb history until irb/ext/save-history is fixed
  * Applied patch by bjencks.
  * Bugfix: rvm gemset delet cucumber now does what is expected.
  * Check in irb fix which shouldn't be needed
  * Bugfix: rvm package install zlib.
  * Whilst putting the cart before the horse can be quite amusing, reality sets in after we do not get to our destination.
  * Bugfix: rvm system now correctly appends instead of prepending rvm bin path.
  * Apply patches after running ant dist if installing JRuby Head.
  * Array!
  * Cleanup any swap files found in rvm_path, if they exist.
  * Missed a few variables during teardown, thanks bjencks!
  * Bugfix: Adjusted loading detection to accommodate for ZSH. Thanks eregon.
  * Added ~/.rvm/hooks/after_cd hook ability to RVM.
  * Simplified rvm function detection.
  * RVM now detects whether it is loaded in the current shell as a function when sourced.
  * Altered the way that rvm_loaded_flag is set for byrnejb.
  * Updated ebuild for latest release.

== Release 1.0.9
  * Bugfix: Initial gemsets are now behaving.
  * Bugfix: Default log path to rvm_path/log
  * Still working on fixing initial gemset import, commented out while debugging.
  * Bugfix: needed the extra level of interpolation.
  * Fork! Fork! *BOOM*
  * Bugfix: rvm alias list. rvm X --default. rvm list default.
  * Bugfix in alias creation, will no longer duplicate.
  * Bugfix: Removed [[ keyword from around md5 comand test.
  * Going for the throat, explicitely.
  * Moved tests in preparation for the separation.
  * Bugfix: jruby cp issue.
  * Explicitely export all RVM variables inside scripts.
  * Bugfix: Removed extra line from PATH parsing.
  * Removed start of line from awk, only doing a single export now.
  * Quote out actual_file
  * Do not unset result.
  * Updated ebuild for latest release.

== Release 1.0.8
  * Fixed double or nothing bug.
  * Almost there, double or nothing eh?
  * This time I have ZSH to thank for finding a bug.
  * Cleaned up upgraded/migrate usage().
  * Missed a spot.
  * Bugfix: rvm gemset list. Thanks ianw!
  * Maglev 24209 -- Rails 3.0.0 Support
  * Defaulting rvm_gems_path
  * Ensure bin_path has defaults
  * Grumble.
  * Environment is much cleaner new. More code cleanup.
  * Bufix: solved the case of the missing line.
  * Bugfix: Fixed typo, setting defaults now works.
  * Missed a spot.
  * Bugfix: prefix set in env no longer carries through to wrappers.
  * I am an arse. I know better than to use find/replace :/
  * Setting source directory explicitely.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Find and replace? Yes. It is that technique where you take perfectly working code and replace it with bugs.
  * Bugfix: location of rvm_ruby_src_path was not set.
  * Fix zsh completion for gemset commands
  * Fixing zsh completion syntax
  * rvm_tmp_path no longer defaulted in global namespace.
  * rvm_docs_path no longer default in global namespace.
  * rvm_log_path is no longer in the global namespace
  * Removed rvm_src_path from global exports.
  * rvm_archives_path, some more code cleanup.
  * rvm_config_path and rvm_rubies_path
  * Removed rvm_environments_path and rvm_wrappers_path.
  * Removed rvm_hooks_path from configurable.
  * Run in parallel, saves a few seconds or more depending on the # of gems in a gemset.
  * Removed 'info: ' prefix from info, now labels only show for other levels.
  * Feature: rvm gemset unpack Bugfix: ruby_string() now correctly grabs the current ruby string.
  * Removed redundant libs, as requested by the department of redundancy department.
  * Added --trace and --verbose options to rvmsudo.
  * bugfix: rvm --shebang inspect gem
  * Safely strip rvm elements from the PATH.
  * Updated ebuild for latest release.

== Release 1.0.7
  * Bugfix: rvm gemset create X
  * Bugfix: ensure rvm reload you know... reloads?
  * Cleaned up installer some.
  * Bugfix: rvm_pretty_print_flag now actually prints with colors in rvm list.
  * Visual cleanup on list.
  * Bugfix: find -iname ordering, thanks matti
  * Missed a spot!
  * Trimming down more, s#rvm_gemsets_path#rvm_path/gemsets#g
  * Trimming down more, s#rvm_scripts_path#rvm_path/scripts#g
  * Unset head_flag when an rvm call completes.
  * Reflect that p378 is the default in list known.
  * Modify default annotation based on suggestion from gitmate on github.
  * Set empty binaries correctly
  * Bugfix: rvm gemset empty now works (tyop). Added extendedglob to zsh.
  * The good news is I think I found the culprit. The bad news is I have to recompile 1.9.2 again to test this.
  * More cleanup on scripts/manage.
  * Carefully handle binaries array.
  * Fun with find, Scene I, Take III.
  * More fun with find and seek!
  * I just *love* the way CentOS keeps their systems up to date :/
  * Bugfix: bashd zsh.
  * I need to go back to kindergarden and learn how to type.
  * More fun with ZSH.
  * Removed -G, --archives, --src path options in preparation for consolidation and "system vs user".
  * Removed exit on cleanup.
  * Some people like consistency too much :/
  * removed gemset separator from global initialize.
  * Updated ebuild for latest release.

== Release 1.0.6
  * Tweak bison detection.
  * Another performance tweak, this time to selector which is called neigh every time.
  * Much work with the loco locals.
  * Allow ruby-1.8 in 1.8 compatible rubies.
  * Slight cleanup on gemset_snapshot
  * Went one level too deep.
  * rvm list much faster feedback now.
  * Bugfix: "rvm use/install/... jruby-head" no longer inserts the version.
  * Added simple CLI parsing to install-system-wide
  * Use rvm_revision to specify a particular git revision of rvm to install
  * Turns out maxdepth 1 is MUCH faster than simply specifying the depth.
  * ls > /dev/null
  * Change to an array
  * Account for extra spaces.
  * Much faster version gathering.
  * Explicitely remove default from set operations.
  * * wayneeseguin sprays aliasbgone
  * Ensure ruby string is set.
  * Ever so slowly spreading my cheeks to remove my head...
  * Who stole my bloody quote? Cheap bastard...
  * Removing usages of =~ so as to not be "idiotic", by the power of GreyCat!!!
  * Altered git detection.
  * Make configure flags immune to the mass cleanse.
  * Explicitely set rvm_ruby_configure_flags when possibly first used.
  * Bugfix: do not quote args of the regex.
  * Slight cleanup of rvm binscript.
  * Simplification thanks to ashb.
  * Bugfix: RVM.tools_strings('1.9.2')
  * Bugfix: rvm update
  * Updated ebuild for latest release.

== Release 1.0.5
  * More hashtags
  * tyop fix, thanks eduardohl
  * The world is not yet ready for hardcore bondage...
  * I comand thee!!! ... Why do you not listen?!
  * Balls out...
  * Push... Pop... *Poof*!!!
  * Put back in the cwd :)
  * Fixing an issue caused by me not having a clue about bash programming.
  * Bugfix: Space strippers to the rescue!!!
  * Bugfix: rvm gemset copy a@b c@d
  * Got the lil bastard that time!
  * '1.8.7@rvm-site gem env gemdir' works as expected
  * Made ruby specific variables more consistent.
  * Working on Remears request, hash tagging the installations.
  * More progress.
  * Merged --trace and --debug, respecting differences with zsh.
  * Merge branch 'master' of git.overnothing.com:rvm
  * More consolidation.
  * Update tools with a minor fix
  * Bugfix: __rvm_environment_identifier now returns proper env id again.
  * Bugfix: Adjusted the way CLI arguments are parsed.
  * Updated ebuild for latest release.

== Release 1.0.4
  * Bugfix: rvm gemset use X
  * More installer cleanup.
  * Removed spinner and sleep from install. While they were neat, non-interactive installs did not like them ;)
  * Tweaking install messages.
  * Bugfix: rvm gemset use <gemsetname>, thanks owen1
  * Bugfix: tyop in CLI, thanks to RichGuk!
  * Updated ebuild for latest release.

== Release 1.0.3
  * Bugfix: Gemsets are now working as expected again.
  * Added pretty print to Upgrade notes.
  * Added rvm_pretty_print to rvm notes, thanks eregon.
  * Bugfix: Bandaids go sticky side down. (gemset sticky flag now set when expected).
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Bugfix: global cache return value.
  * Quote $PATH when used with printf to defined $new_path. This allows spaces in $PATH.
  * Fix ZSH completion for the new command disk-usage
  * Fixed tyop, added consistency
  * Bugfix: default gemsets now import.
  * Let us be more direct, shall we?
  * Thanks to Sutto (Darcy) for pointing out the obvious.
  * Turns out older bash shells could not handle the redirect operator :/
  * Added error handling around the sourcing of primary scripts when loading RVM.
  * Bugfix: ZSH did not like unset/declare.
  * ZSH goosed me.
  * Finally got around to fixing scripts/log ;)
  * Forgot to export PS4, thanks thewoolleyman!
  * Bugfix: rvm default gemsets now load properly.
  * Ten Thousand Lines... will give you such a crick in the neck!
  * Returns are now through utility and some of gemsets
  * More slow progress making things more robust.
  * Added "rvm strings" into CLI. More returns. More cleanup.
  * Tweaked rvmrc trust message wording. Added variable name and explicit returns to a few functions for clarity.
  * Speed up scripts/log by using builtins. Removed stray xtrace off.
  * Added command locations for bash/zsh in rvm info.
  * __rvm_environment_identifier() is now using strictly shell builtins, should also work in more cases now.
  * Default all logging to terminal to not use colors. set "export rvm_pretty_print=1" in ~/.rvmrc to override this.
  * Make that more of a sanity check until I track this bug.
  * Skip patching if it is not a file.
  * More headway with --patch.
  * Bugfix: rvm info
  * Arrays make me feel shifty... Disco Fever!
  * Bugfix: extract gem_prefix properly. Thank you sikachu!
  * We want to eliminate all spaces.
  * Ensure we are calling a binary for gem in gem_install
  * Updated ebuild for latest release.

== Release 1.0.2
  * Bash completion for help subcommand.
  * Escape newlines for old shells.
  * Add known rubies completion for install subcommand
  * Add bundler to ree global gemset.
  * Yet another space stripper... How drunk was I last night? ...
  * Simplifying space strippers, I was over thinking things.
  * Removed scripts/manpages, turns out that manpath finds it based on PATH, reduced complexity yay!!!
  * Commented out manpages, should be found based on PATH by manpath
  * Bugfix: Arg parsing in package
  * Turns out the match, was not a match.
  * wow... I really need to go back to gradeschool...
  * Dodge Z alias!!!!!!!
  * Found two more squealers
  * Someday the subtle differences between zsh and bash are going to drive me batty :-p
  * Patch splitting moved to internal.
  * Begone relic of the past.
  * Bugfix: Account for missing gemset.
  * BugFix: Bugfix Fixed.
  * Bugfix: matching in 18 compatible ruby based on new grep. Plus more cleanup.
  * Very slowly cleaning everything up.
  * Clarified the .rvmrc trust message a bit.
  * Suddenly, I feel like watching LeekSpin for an extended period of time... ( http://leekspin.com/ )
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * More space $HOME friendly.
  * Remade symbolic links of 1.9.{1,2} global gemsets to that of 1.8.7.
  * Updated gemsets to use final release of Bundler.
  * Make __rvm_update_rvm extract correct, with thanks to loumz for pointing out the source of the problem
  * Bugfix: because some people are perfectionists ::cough:: dbussink ::cough::
  * Updated ebuild for latest release.

== Release 1.0.1
  * Missed a few spots.
  * Consolidated path cleanup code, removed paste as it is a high profile alias target. Some minor tweaks.
  * Copy across bundled gems as part of the jruby install process
  * Merge branch 'zsh-warning-fix'
  * Actually commit the damn file
  * Merge remote branch 'origin/happy-fun-docs-time'
  * Update load-rvmrc reference
  * Add more docs
  * Merge remote branch 'origin/path-fix'
  * Simple fix to make sure rvm is added to the path, even with system loaded
  * Typo broke rvm list known
  * I encourage you to learn more about your shell every day, it will be beneficial.
  * A debugging we will NOT go...
  * Properly detect interactive sessions.
  * Improve ruby api trust-checking, primarily for passenger stuff
  * Removed the 'fun with perl' items, some people have no sense of humor.
  * Prevent unintentional exit code 1 when sourcing scripts/rvm
  * alias why dost thou hateth me so...
  * s/$(pwd)/$PWD/g
  * Add gem hook
  * Manually rehash whenever path is set
  * Merge remote branch 'origin/better-path-handling'
  * Handle conditionally adding rvm to the path
  * Updated ebuild for latest release.
  * RVM 1.0.0
  * Fix set operations
  * Check trustworthiness around whole thing
  * Implement rvmrc loading security
  * Merge remote branch 'origin/switch-to-bzip'
  * Add bundler to rvm gemset
  * make rvm use bz2 for mri rubies
  * Merge remote branch 'origin/auto-install-bundler'
  * Merge remote branch 'origin/head-installer-fix'
  * Add check for 1.8.7 on 1.9.2-head
  * Make rvm automatically install bundler as needed
  * Rehash binaries on switch, forcing it to forget seen executables / lookup new path
  * Add zsh completion script
  * Problem with installing glib on mac os x snow leopard. Fixed by adding a -I compiler flag and setting the path for pkg-config. Also added installation of pkg-config and gettext to glib function instead of mono function
  * JRuby 1.5.2 is now default for JRuby. Thanks for the heads up stepheneb.
  * And lo we fight the evil alias Hydra wherever a head may rear.
  * Updated ebuild for latest release.

== Release 0.1.47
  * Merge remote branch 'origin/generate-default-wrappers'
  * Merge remote branch 'origin/set-warning'
  * Make it generate default wrappers as expected
  * Fix rvm_project_rvmrc_default
  * Show a warning on set operations when passed what look like options
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Merge remote branch 'origin/xargs-fix-dangit'
  * Merge remote branch 'origin/revert-set-all'
  * Change the default behaviour of the set operations, fix the rubies option
  * Make basename have the argument seperator
  * Add uninstall to the blacklisted action
  * Make manage receive the correct arguments, pass correct string
  * Don't allow $rvm_gemset_separator in gemset names (e.g. "my@gemset@rocks"): It works fine when you create the gemset, but fails in interesting ways when trying to delete it.
  * Merge remote branch 'origin/hudson-plugins'
  * Adjusted notes for apt based systems, thanks jmettraux.
  * Added 1.9.2 rc1/rc2 to known.
  * Add plugins to the repo
  * Updated ebuild for latest release.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * 1.9.2-p0 is now default, w00t!!!
  * Typo in github url.
  * Add install system wide fixes for xargs
  * Bugfix: Fixed a *very* irritating bug related to cd "hanging" on exit sometimes.
  * fix -G, --archives, -source options
  * Altered rvm info to report both zsh and bash versions.
  * Correct restrict basename argument count
  * Fix installer showing the source line
  * Merge remote branch 'origin/rvm_bin_path-fix'
  * Correctly calculate paths to remove double-slashes
  * Add default-with-rvmrc / rvmrc for rvm set operations.
  * Fix minor issue with rm -rf
  * Blasted aliases.
  * 1.8.7-p302 is now default (Security Vulnerability Patch Level).
  * Merge remote branch 'origin/system-wide-tweaks'
  * Add system wide rvm tweaks
  * Merge remote branch 'origin/set-exec-fix'
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Maglev 24067.
  * Fix set exec options
  * Use default rvm for rvm-auto-ruby
  * Updated ebuild for latest release.

== Release 0.1.45
  * Fix rvm_prefix correction logic
  * Refactor rvm migrate to take into account aliases and wrappers
  * Implement rvm upgrade
  * Merge branch 'rvm-migrate'
  * Implement item+alias as shorthand on rvm use for creating aliases
  * Cleanup how rvm_prefix works
  * Merge remote branch 'origin/no-hardcoded-env-path'
  * Implement rvm migrate
  * Don't hardcode rvm_environments_path inside the rvmrc
  * Make rvm gemset copy actually work correctly again
  * Added missing file append (>>) in ebuilds.
  * Use grep to suppress some noise when running a root installation as non-root.
  * Typo fix: __rvm_ensure_has_enviroment_files -> __rvm_ensure_has_environment_files
  * Apply ebuild changes from 99999 to template.
  * Remove broken and unnecessary installation of "environments/system" file from ebuild.
  * Added some informative comments to the ebuild.
  * Moved some ebuild template lines around to minimize differences between git-based ebuild and regular ebuild.
  * Rename variable: rvm_sandboxed -> rvm_selfcontained .
  * A little more cleanup. Also, please use two spaces no tabs for this project. Thanks!
  * Minor cleanup.
  * added code to fallback to http:// if git:// or ftp:// fails.  This allows rvm to work behind corporate firewalls with http only access to the internet
  * Fixed system var not getting set correctly in scripts/maglev for OpenSolaris environment.
  * Apply recent ebuild template changes to rvm-99999.ebuild .
  * Removed "touch system" from ebuild, since rvm itself should take care of this.
  * Merge branch 'set-operation-tweaks'
  * Add optional targets for the set operations
  * Updated ebuild for latest release.

== Release 0.1.44
  * Updated ebuild for latest release.
  * Implement rvm_ignore_rvmrc, to do installs without rvmrc files
  * Move __rvm_environment_identifier back to utility to avoid conflicts.
  * Correctly expand rubies
  * Make rvm gemset copy correctly report the err with no args
  * Fix the ebuild
  * Misc tweaks to the sandbox installer
  * First set of work on implementing rvm_sandboxed
  * Fix __rvm_quote_args_with_shift
  * Totally not the droids you are looking for.
  * Merged converter by Darcy.
  * sh safe environment files.
  * Fixed ree named install
  * What... you want MORE?
  * Cleanup, aisle 3! Named installs actually compile now :)
  * correctly use rvm_ruby_name in blank selector
  * Adjust package name for ruby when name is used.
  * StripNzN
  * Feature: Named installs.
  * Fix rvm update --rubygems
  * Misc code tweaks, including converting not -z to -n
  * Properly expand the path for install
  * Install current rubygems correctly
  * Rename textmate_ruby to rvm-auto-ruby since it's universally useful
  * Fix rvm update --rubygems
  * MANPATH gets clobbered after rvm loads. Reversing the variables seems to help.
  * Bugfix: when cd fails properly report the exit status.
  * A single textmate_ruby for all!
  * update rvm opts and add snapshot command to completion
  * Added some sanity checks to file removals.
  * Default rvm flags before first use when loading.
  * Added no-default option to rvm-prompt
  * Prevent an alias of "tr" from "breaking" RVM
  * Removing rdoc from global and default gems.
  * Allowing the aliasing of digits directly.
  * MagLev 23913
  * Added an extra line detailing what MRI/ree/rbx stand for to notes, thanks douglascamata.
  * Added a warning message with a pointer to docs for when irb cant load readline. Thanks douglascamata.
  * Temporarily reverting rvmsudo until we talk things out with thewoolleyman.
  * Added sanity to the patchsets installer.
  * Refactor how alias, docs and rubygems are invoked to be consistent
  * Ensure we set the path
  * Clarified a generating message, Thanks cehoffman!
  * Fyxed a tyop, Thanks cehoffman!
  * Improve rvm-shell to take into account .rvmrc
  * Implement rvm-repair
  * Set path variables with a check for valid path.
  * Updated ebuild for latest release.

== Release 0.1.43
  * Merging Darcys record-install-commands branch.
  * rvm_patches_path will be created by following lines
  * Implement strings on 'rvm tools'
  * Implement rvm snapshot {save,load}
  * Updated ebuild for latest release.

== Release 0.1.42
  * Add missing info functionality to api, fix list_strings output
  * Implement rvm load-rvmrc
  * Merge remote branch 'origin/rvm-usage'
  * Make rvmsudo use -E
  * Implement rvm disk-usage
  * Merge branch 'master' of git.overnothing.com:rvm
  * Feature: May now switch gemsets for the current interpreter via 'rvm use @gemsetname'
  * Refactor the way clang integration works
  * Escape percentages in the message
  * Implement --clang option when install rubies.
  * MagLev Palindrome Release.
  * Use the actual environment identifier
  * Revert the code to force 32bit, simplify 64 bit checks
  * Merge remote branch 'origin/multiple-ruby-management'
  * Merge remote branch 'origin/man-fixes'
  * Merge remote branch 'origin/install-tweaks'
  * Fix invocation of scripts/manage with multiple rubies
  * Correct set the default rvm_prefix
  * Tweaks to how rvm_prefix is handled in scripts/initialize
  * Miscellaneous tweaks to the install proce
  * Removed notice about 1.8.7 patchlevel now that it is back to latest. Thanks blowmage.
  * Fix the install process for man pages, generate both versions
  * Replace readline fix with one that doesn't need a patchlevel
  * Remove archives if interrupted mid-download
  * Add install-system-wide
  * Add is-at-least check
  * Refactor the way rvmrc is checked to make it reusable outside of cd
  * Revert "Installer seems to be a bit jacked up somehow... fixing."
  * Installer seems to be a bit jacked up somehow... fixing.
  * Added an empty scripts/man to prevent silly error messages.
  * Modify rvm-shell to take the optional first argument as a ruby string
  * Fix the check on for arg count in scripts/wrapper
  * Nice... missed the debugging comments & code from the contribution.
  * Added mkdir of rvm_patches_path during install, thanks niw!
  * Fix and improve openssl options
  * FIX: spaces, missing options
  * Merge remote branch 'pistos/respect-rvm-prefix-3'
  * Fix implode spelling error in completion
  * Adding manpage
  * Fixed a tyop.
  * Merge branch 'wrapper-tweaks'
  * Merge of Darcy's work on rvm-shell
  * Tweaks to wrapper generation
  * Add backported openssl fixes to a patch
  * Merge branch 'master' into respect-rvm-prefix-3
  * Miscellaneous bug fixes, namely related to exception
  * 1.9.2 is now defaulted to rc2, w00t!!! Thanks Pistos!
  * Tweak for the rvm install process
  * Use correct item
  * Simplify the md5 code
  * md5 should have more info
  * Make scripts/md5 work correctly on ubuntu, add md5 sum for the latest ree
  * Add ability to override the command check in certain situations
  * Bug fixes galore - also, use_from_path!
  * Implement tools in the ruby api, fix a few misc bugs
  * Add scripts/tools, implement identifier and path-identifier
  * Since we are breaking out of the loop, this does not actually do anything on reflection.
  * Initial Ruby API, written by Darcy!!!
  * Updated ebuild for latest release.

== Release 0.1.41
  * Feature: Added 'rvm list known_strings', thanks to lenary for the idea.
  * Maglev 23767.
  * Do *not* use 1.9.1-p429. http://redmine.ruby-lang.org/issues/show/2404
  * Respect $rvm_prefix when checking for root user.
  * corrected grammar (no comma necessary) and made consistent with other "info:" statements
  * Fix for wrong working dir showed on prompt when project .rvmrc is loaded.
  * Commented out dos2unix for now.
  * More misc work on fixing the build process, nameling detecting rubies
  * Don't mangle the supplied path in __rvm_ruby_string_paths_under
  * Defaulting 1.9.1 to p429
  * rc1 is now default for 1.9.2, thanks for the heads up bcg.
  * better fix to allow users to specify patches with absolute path
  * Fix rvm_ruby_configure_flags so that it only replaces commas with spaces when they precede another option, thus allowing option values to contain commas.
  * Patch to facilitate building Ruby for a specific architecture on Snow Leopard
  * Use patchlevel default of 1
  * Merge conflict resolved.
  * Copy files in to the correct man path
  * Simplify doc building process to remove docbook2x requirement, update docs
  * [WIP] Work on tweaking the build process for docs
  * Add progress details to the docbook process
  * manpath initialization a bit corrected
  * manpage itself corrected
  * installation script updated to install manpages
  * Basic manpage for rvm implemented.
  * Expand patch name support
  * Start of refactoring on patches support, including patchsets
  * Implement --patch{,es} support in rvm.
  * Ruby 1.8.7-p299, w00t!!!
  * Fix trailing s in the prompt
  * fixes pkgconfig bad url for curl
  * fixes iconv bad url for curl
  * Updated ebuild for latest release.

== Release 0.1.40
  * Merge remote branch 'origin/list-fixes'
  * Fix rvm list for architecture wrt gemsets
  * Reimplement the global cache, controlled via rvm gemset globalcache
  * Merge remote branch 'origin/gemset-update-and-tweaks'
  * Add rvm gemset update to the usage
  * Implement rvm gemset update and add a bit more info to set output
  * Refactor script/gemsets to have a usage message
  * Correctly generate an irb wrapper for rubinius
  * Use 'rbx irb' on rubinius
  * Start of refactoring for rbx-irb
  * Implement rvm cleanup
  * Refactor scripts/info
  * Start replacing common inclusion patterns with $rvm_scripts_path/base
  * Remove ruby binaries with rvm remove along with aliases
  * Check for 1.8 compatible rubies and use them if available.
  * Call __rvm_become before single exec.
  * Merge branch 'warn-on-rubyopt'
  * Show warning on upgrade as well as install
  * Warn if RUBYOPT is present as part of the install.
  * Merge remote branch 'origin/ruby-head-fix'
  * Make ruby-head install rubygems correctly
  * Merge branch 'install-message-fixes'
  * Clarify the message regarding sourcing rvm
  * Fix rvm use --default
  * Make rvm reset really unset all of the old env vars
  * Added libyaml-devel libffi-devel to yum based distros, thanks rosenfeld for the suggestion!
  * Bugfix: when disk and loaded versions differ, the message now makes more sense.
  * Record packages when they are installed.
  * Feature: package urls are now read from config/db
  * added rvm list gemsets, which is like rvm list rubies, but shows every gemset eh
  * MagLev 23673
  * make rvm update respect the head flag, use http for updating from head
  * Merge remote branch 'origin/rvmrc_cd_refactor'
  * Tickets https://www.pivotaltracker.com/story/show/3870044 (rvm should revert back to the last manually set (or default version) when cd'ing to a directory that doesn't have a .rvmrc file above it.) and https://www.pivotaltracker.com/story/show/3869970 (.rvmrc should not be re-sources when cd'ing under the same project)
  * Version bump, 0.1.39
  * Updated ebuild for latest release.
  * Let users configure the rubygems version to install for a given interpreter
  * Prevent it from trying on rubinius or jruby
  * Make installing different rubygems versions work
  * Added rubygems control script and CLI.
  * Fix bad variable naming
  * Use eval instead of calling exec directly
  * Work on adding rvm exec
  * When showing info for system, don't show the ruby section
  * Fix rvm gemset copy
  * rvm alias create name ruby should check that name isn't a ruby string
  * Fix set action exit code, make benchmark correctly work with sets
  * Fix build options for ree-head
  * Modified rvm-prompt to support using unicode format parameter in conjunction with other format paramters.  For instance "rvm ree ; rvm-prompt u v" will now return "✈-1.8.7". Previously, the unicode parameter would short circuit all other formatting.
  * Bugfix: 'gem' command in rbx now works.
  * Actually fix match
  * Fix issues with unterminated regular expressions in scripts/match
  * Fixed a bug in BTU, added db_test file.
  * Bugfix: scripts/match now works properly again, and the tests are running again!!!
  * Feature: More compatibility with all shells for scripts/match. Thanks to Brian Jones for the motiviation :)
  * corrected patch-prefix presence checking
  * Merged in changes by Yoshimasa Niwa (niw). Thanks!
  * patch prefix handling added; README updated accordingly
  * vim temporary (swap) files ignorance
  * Bugfix: explicitely use the 1.8.7 wrapper for rbx install.
  * Half tolken for a half wit?
  * Feature: Allow common configure options to pass directly through the RVM CLI Example: rvm install 1.8.7 --enable-shared --enable-pthreads
  * Bugfix: gemset_pristine
  * Added/fixed typos for alias and fetch help docs
  * updated test cases for new "s" switch used to add "system" to the prompt when system ruby is in use.
  * Require s (system) switch to return "system" when system ruby is in use.
  * Bugfix: --passenger now regen's wrappers every time.
  * Remove invalid (it seems) rvm_debug_flag stuff in scripts/cli
  * Removed --jit from usage, thanks tmorini
  * Updated ebuild for latest release.
  * Let users configure the rubygems version to install for a given interpreter
  * Prevent it from trying on rubinius or jruby
  * Make installing different rubygems versions work
  * Added rubygems control script and CLI.
  * Fix bad variable naming
  * Merge remote branch 'origin/set-exec'
  * Use eval instead of calling exec directly
  * Work on adding rvm exec
  * Merge remote branch 'origin/system-info-fix'
  * When showing info for system, don't show the ruby section
  * Merge remote branch 'origin/gemset-copy-fix'
  * Fix rvm gemset copy
  * rvm alias create name ruby should check that name isn't a ruby string
  * Fix set action exit code, make benchmark correctly work with sets
  * Fix build options for ree-head
  * Modified rvm-prompt to support using unicode format parameter in conjunction with other format paramters.  For instance "rvm ree ; rvm-prompt u v" will now return "✈-1.8.7". Previously, the unicode parameter would short circuit all other formatting.
  * Bugfix: 'gem' command in rbx now works.
  * Actually fix match
  * Fix issues with unterminated regular expressions in scripts/match
  * Fixed a bug in BTU, added db_test file.
  * Bugfix: scripts/match now works properly again, and the tests are running again!!!
  * Feature: More compatibility with all shells for scripts/match. Thanks to Brian Jones for the motiviation :)
  * corrected patch-prefix presence checking
  * Merged in changes by Yoshimasa Niwa (niw). Thanks!
  * patch prefix handling added; README updated accordingly
  * vim temporary (swap) files ignorance
  * Bugfix: explicitely use the 1.8.7 wrapper for rbx install.
  * Half tolken for a half wit?
  * Feature: Allow common configure options to pass directly through the RVM CLI Example: rvm install 1.8.7 --enable-shared --enable-pthreads
  * Bugfix: gemset_pristine
  * Added/fixed typos for alias and fetch help docs
  * updated test cases for new "s" switch used to add "system" to the prompt when system ruby is in use.
  * Require s (system) switch to return "system" when system ruby is in use.
  * Bugfix: --passenger now regen's wrappers every time.
  * Remove invalid (it seems) rvm_debug_flag stuff in scripts/cli
  * Removed --jit from usage, thanks tmorini
  * Remove type rvm from info, does not apply anymore.
  * JRuby 1.5.1
  * Changed apt-get check to aptitude, overwhelming response that it is far superior.
  * Commenting out rvm_history until we can make the solution more robust.
  * John Trupianos *awesome* contribution to RVM, rvm remove now works properly w00t!!!
  * Use ree 2010.02
  * Fix for zsh wrapper error
  * Refactor the generated wrappers
  * Misc tweaks to the install process
  * Misc fixes and integration for __rvm_run_with_env
  * new rvm env inherits trace flag
  * Introduce utility functions to run stuff in a given env
  * Rearrange where the gem import is run
  * Bugfix: Actually add the code lines to the wrapper file.
  * Added error checking around environment loading in wrappers.
  * Bugfix: sh has '.' not 'source'.
  * Added PATH to rvm info.
  * Bugfix: If default flag is set when wrapper is called as root, link binaries to bin path.
  * When root, default the bin path to /usr/local/rvm
  * Updated ubuntu 'rvm notes' message.
  * rbx-1.0.1-20100603
  * MagLev 23577
  * Merge branch 'repo-folder-tweaks'
  * Refactor the watch rubies are fetched
  * Make test/suites exit code reflect the result
  * Updated ebuild for latest release.

== Release 0.1.38
  * Tweak md5 slightly.
  * Update the order of calls that create the .rvmrc
  * Beginnings of .rvmrc create refactor.
  * Merge branch 'gemset-ruby-strings'
  * Use mkdir -p instead of mkdir
  * Allow importing gemsets into multiple envs
  * Ensure we have the directory first
  * General alias / selector bug fixes.
  * Use subshells directly to import the gemset stuff
  * Fix recursion in alias - thanks to fermion for the bug report
  * Use --alias instead of --aliases
  * Add --aliases option to rvm install
  * Record each rvm command to ~/.rvm_history
  * Promote 'rvm notes' message to the top of upgrade notes.
  * Removed install_source_path for gemsets
  * Ensure remove correctly deals with the alias, ensure system has a blank environment file
  * Updated ebuild for latest release.
  * Implement 'rvm gemset prune'
  * Generate wrapper by default, fix shift for wrapper arguments
  * Use find and misc enhancements in scripts/install
  * Fix default and system on sets
  * Added header in 'rvm list known' for MRI Rubies
  * Refactor the way wrappers are used internally
  * Make that a quad espresso.
  * Bugfix: I need more caffene :/
  * I will be attending remedial commit training next week.
  * Bugfix: initial gemsets pathing.
  * How did that happen???
  * Merged Darcy's repo directory changes.
  * Bugfix: No longer spew errors on Importing gemsets part of install.
  * Bugfix: filesystem key-value db now properly handles kinky values.
  * Feature: May now specify default configure flags for MRI Rubies. Set in ruby_configure_flags in ~/.rvm/config/user.
  * grr...
  * Feature: Nested {default/global/gemset_name}.gems files from ~/.rvm/gemsets.
  * Minor version bump.
  * Updated ebuild for latest release.
  * 1.9.2 defaults to preview3
  * Updated install notes for p174 switch.
  * 0.1.36 version bump.
  * Default 1.8.7 p174: 2010-05-31 13:47 <@wayneeseguin> drako: OK .. what are you suggesting to put 174 as default? 2010-05-31 13:47 < drako> wayneeseguin: yes 2010-05-31 13:48 < drako> because is a p248 related bug 2010-05-31 13:48 < drako> in 1.9.1 and head-ruby rails3 works ok 2010-05-31 13:48 < drako> but rails 2.3.x wont work ok with ruby 1.8.7 >= p248 2010-05-31 13:48 < drako> and since its still the stable branch
  * Add in log levels to shell log output lines.
  * allow for installing with a prefix
  * Merge branch 'gem-install-fixes'
  * Make rvm gem install act as expected, don't call out to rvm gemset install
  * Merge branch 'docs-in-install'
  * Remove trailing semicolon
  * Call cd . after rvm reload, casuing it to reload rvmrc
  * Allow users to install docs as a part of the install process
  * Update rvm_environment_identifier to respect system and the current state of ruby
  * Correct negate the bison command
  * Re-add the trailing newline for logging. Check for no bison and return from install.
  * Check for bison when installing ruby head
  * Remove extra commented lines
  * Updated ebuild for latest release.

== Release 0.1.35
  * Merge branch 'set_refactoring'
  * Add newline after use statements
  * Refactor the way set works, using rvm_ruby_strings
  * Minor refactoring to how __rvm_environment_identifier works
  * Typo fix in installer, thanks to noocx.
  * unset rvm_ruby_strings inside of __rvm_teardown
  * Refactor rvm_ruby_version's use for multiple rubies to be rvm_ruby_strings
  * Use rvm_ruby_strings in set and clean up the variable
  * Updated ebuild for latest release.

== Release 0.1.34
  * Change the way info is called, use the correct environment identifier
  * Fix the way ri generates doc, installing them into system
  * Update the notice for downloading rvm
  * Removed extra line on log output.
  * Clean up rvm install message more.
  * Added config/known file.
  * Features: 'rvm list known' now returns immediately and does not include svn. 'rvm list ruby_svn_tags' now lists the ruby svn tags available. 'rvm list known' alters behavior based on context.
  * Alter log output for better consumption by external tools without loosing the level.
  * Bugfix: If you do not have a system ruby installed rvm should load the default properly.
  * Added contrib/gemset_snapshot script.
  * Removed global gem caching. Excellent idea, however, it does not work for all use cases.
  * Feature: __rvm_setup / __rvm_teardown Thanks to amikula: http://github.com/amikula/rvm/commits/790cfa052702be6c3d7874af6b6646ec321b843a
  * Fix scripts/info wrt printf
  * Updated ebuild for latest release.
  * Feature: MRI Ruby URLs are now configurable from config/{user,db}.
  * Fix for __rvm_gemset_gemdir
  * Bugfix: Set rvm_ruby_gem_path in selector.
  * Tell users in rvm notes that they need 1.8.7 for 1.9.2-head / rbx. Thanks jmettraux!
  * Bugfix: Be much more assertive about loading the default environment.
  * Feature: 'rvm gempath', 'rvm gemhome', similar for gemsets.
  * Unset rvm_ruby_string if rvm has not yet been loaded.
  * Reimplement --default using alias and handle migration
  * Bugfix: Account for multiple lines being in the default file.
  * Bump version #.
  * Add rvm_gemsets_path fix
  * Initial post-install gemsets code.
  * Allowed gemset to pass through on empty action.
  * Made the post-help message more helpful.
  * Made post-help message more concise.
  * Added scripts/list.
  * Remove System from list.
  * Bugfix: 'rvm info' now reports correct environment information.
  * Logging output now feeds a newline at the end.
  * 'rvm list known' shows 1.0.0 for rbx- default. Thanks Defiler.
  * Bugfix: 'rvm install rbx' now properly downloads the source when the archive is not correct.
  * Added a missing line break.
  * Changed 'echo -e' to 'printf'.
  * Proper quoting for echo of parameters.
  * rvm info without parameters now runs in current env.
  * For Rubinius call configure with ruby configure.
  * MagLev 23530
  * Bugfix: missing test operator
  * Add initialize to scripts/info
  * Add rmv env (with option --path) to get environment info
  * Add documentation built into rvm for wrapper
  * Implement environment files and switch symlinks for wrapper scripts
  * Silencing if GEM_HOME does not exist. Thanks Sutto.
  * Append to file instead of overwrite.
  * Feature: generate ri-site / ri for real this time.
  * Sticking with the default -client for jruby tarcieri.
  * Correct the json output for successful and errors, ensuring it wraps the rubies correctly
  * Added 'rvm help info'
  * Extra space after ruby version in output
  * 'rvm info' is now an external script callable by sections and can specify rubies..
  * Adjusted rvm-prompt sed based on Sutto's comment.
  * Remainder of our changes from pairing this morning with Sutto.
  * Bugfix: rvm-prompt double dash bug in rbx, thanks be to Sutto.
  * Bugfix: rvm-prompt double dash bug, thanks be to Sutto.
  * Bugfix: rvm 1.8.7,ruby-head ruby -e 'p :t' works properly.
  * MagLev 23508.
  * Bugfix: JRuby gemsets now work properly, including 'rvm gemset list'. 'rvm gemset list' also is much improved.
  * Updated ebuild for latest release.

== Release 0.1.32
  * Added 1.9.2-head to list known now that there is a branch for it. Thanks altogether!
  * Bugfix: removed /bin from autoconf install path.
  * Beware the user aliases... Thanks be to ice799!!!
  * Default rbx built to use --skip-system for LLVM, thanks postmodern.
  * Prevent 'bad things from happening' when specifying 'rubinius', thanks tmm1.
  * patchlevel tweak.
  * You see nothing...
  * Rubinius 1.0.0 refactoring.
  * Rubygems 1.3.7 is now default.
  * Missed a variable change with last commit.
  * Hooks may now alter the current environment.  Please be very careful what you place in them :)
  * Updated ebuild for latest release.

== Release 0.1.31 - JRuby 1.5.0 fix for readers of RubyInside.
  * Sortof Bugfix: Adjust rake for a minor relase issue. Thanks to haruki_zaemon for notifying me of this issue.
  * Updated ebuild for latest release.

== Release 0.1.30
  * JRuby 1.5.0 w00t!!!
  * Updated install message for && return. Thanks to panaggio.
  * Updated ArchLinux MRI deps.
  * 'rvm gemset pristine', thanks be to jschoolcraft.
  * Added initial 'rvm help ruby' text.
  * Added initial 'rvm help rake'
  * Rubinius rc5
  * Bugfix: Account for parse args now arg quoting.
  * Pass rvm_ruby_configure_flags through to rbx, thanks goes to khaase.
  * Maglev 23464.
  * Handle command line args with spaces (e.g., REE build options).
  * Run an 'svn switch' when updating a svn repo.
  * 1.9.3 is now 'ruby-head'
  * Removed --no-dev-docs from ree install. use ree-options instead.
  * MRI 1.8.7-p249
  * Export rvm_ree_options.
  * Minor tweak to rdoc generation.
  * Bugfix: 'rvm use X' now prefixes gems bin directories to path also. Thanks erikh.
  * PATH order: gem bin:global gem bin:ruby bin:... Thanks for the great idea erikh!!!
  * JRuby 1.5.0RC3
  * Removed --verbose from rdoc call.
  * Updated ebuild for latest release.
  * MacRuby 0.6
  * Made installation message regarding && return more clear.
  * Minor version bump.
  * Beginnings of 'rvm help'
  * Bugfix: 'rvm gemset use X' now works properly again.
  * Do not unset rvm_ruby_string everywhere, it is meant to be used for scripting.
  * Cleaned up package.
  * Bugfix: package install autoconf.
  * Bugfix: Account for rvm_symlink_path not existing.
  * MagLev 23400
  * Added zlib1g to rvm notes for apt hosts.
  * MacRuby nightlies should come from macruby.org
  * :) lets make this a three step process hmm?
  * Account for spaces at the beginning of the line also with rvmrc sanity check.
  * Bugfix, old exports.
  * Thank you Maz for your sharp eye.
  * Overzealous.
  * Better export handling in CLI, moving towards sh compatibilty.
  * Added Sanity checks to two more locations.
  * Check for users that do not read the documentation before loading /etc/rvmrc and/or ~/.rvmrc, thanks iotaion9.
  * Don't copy and paste folks, it gets you into trouble. Pure typing is the way to be :)
  * Feature: after_install hook :) Look Ma, it's already documented.
  * MagLev 23351.
  * Be silent if no system ruby is found.
  * Bugfix: Display system ruby correctly in rvm list when it is a symlink.
  * Removed extra $dir
  * Bugfix: rvm gemset copy.
  * djanowski.
  * Openssl version bump -> 0.9.8n
  * Removed creation of rvm_symlink_path and .gem/cache
  * Added RUBYOPT to 'rvm info' output.
  * Bugfix: Squished an oompa loompa.
  * Scaling back alias, went overboard last night :)
  * Time to go back to bed.
  * Bugfix: xdg-open detection now proper, removed OS type test.
  * Added xdg-open for systems which have it.
  * Bugfix: Don't you wish we could mute some people the same way? ::grin::
  * Bugfix: rvm-prompt for system rubies, corrected awk.
  * Bugfix: gemsets line 311, thank you mgutz.
  * Features: 'rvm alias create [ruby] [name]' 'rvm alias delete [name]' 'rvm alias list'
  * Added docs feature. Thank you Paul Barry (pjb3)!!! w00t!!!
  * Logical negations are fun!!!
  * s/which/POSIX command -v/g
  * Bump zlib version to 1.2.5
  * Bugfix: Adjust monitor for new set extraction.
  * Added libreadline6-dev and subversion as dependencies for apt.
  * Made rvm gem install output slightly more clear.
  * What do you mean you need to specify ./configure?
  * Might possibly add libxml2 to package.
  * Bugfix: Account for LoadError in irbrc, thanks to Shinzui!
  * More IR progress.
  * IronRuby 1.0 just about functional.
  * Maglev Update.
  * Fun with java.
  * Updated ebuild for latest release.
  * Bump version #.
  * JRuby 1.5.0.RC1 is now JRuby default.
  * Silence grep when not found.
  * damn copy paste
  * --ree-options --no-dev-docs default now for ree
  * Updated for cent 5.4 iconv-devel MIA.
  * Bugfix: do some more sanity checks when using a gemset.
  * Bugfix: Fixing the last bugfix.
  * Bugfix: Switch gemsets when already using one.
  * If gemset name was specified, explicitely use it.
  * Add more detail to the post-install gem installations (eg, where they are installing to).
  * Bugfix: 'rvm answer' now uses perl, since the universe is written in Perl. As it is obvious... the universe has bugs, and perl is the only language that can have bugs not even god could sort out.
  * Bugfix: 'rvm question'
  * 'rvm question'
  * 'rvm answer' now answers the question: What is the Answer to the Ultimate Question of Life, the Universe, and Everything?
  * Improved rvm info output.
  * Added zlib to notes.
  * Account for term type 'unknown', thanks Chad Woolley.
  * Adjustment to gem for rbx-head.
  * Bugfix: Rubinius is now able to use gemsets also :) Thank you luislavena!
  * Dumbass. It's like you never awk'd before...
  * When called with only one ruby, allow no args.
  * Now can set rvm_verbose_flag=0 to silence set log.
  * Made progress on IronRuby during coderpath interview.
  * Bugfix: don't relink caches anymore.
  * Improved output for gemset empty.
  * Bugfix: Don't select if gem_home set.
  * Install autoconf to rvm bin path / symlink path.
  * Sometimes I wonder why we have copy/paste...
  * Added variable.
  * Added autoconf package url.
  * Feature: 'rvm package install autoconf'
  * Bugfix, grab the gemdir properly for destination in copy.
  * Updated ebuild for latest release.

== Release 0.1.27
  * Remove .ext/rdoc if it exists, for those having trouble with it when installing 1.9.2-head.
  * Applied jhsu's patch.
  * Updated rvm-prompt tests to run rvm prompt in correct directory. Also updated 1.9.1 and 1.8.6 tests to use the correct 'head' versions
  * initial bash completion
  * I'll think about this more.
  * Bugfix: only warn when using sytem.
  * Do not store system ruby as root.
  * Added nice warning message about using gemsets with System rubies.
  * Be sure to practice safe sed...
  * Updated Maglev version to 23191.
  * Reconfigure always.
  * Bugfix: don't unset rvm_gem_name during installs.
  * Updated ebuild for latest release.
  * Minor CLI cleanup.
  * Added rvm-update-{head,latest}
  * Bumped minor version.
  * What? sed is not actually clairvoyant???
  * rdoc/rake now install both to interpreter gemset and interpreter global gemset.
  * Change % to @ during update in default file.
  * Updated scripts/install.
  * Fixed rvm_bin_path in example rvmrc, thanks uxp.
  * Adjusted ncurses url, thanks agibralter.
  * Install rdoc/rake with no rdoc/ri option.
  * Install rdoc before rake.
  * Added 'system' output to rvm-prompt, thanks workmad3.
  * How'd that sneak in there?
  * 'rvm install rbx' now installs rc4.
  * Ignore dependencies when loading a gem.
  * Updated installer to output differently for install vs upgrade.
  * Bugfix: Improved check for no gem command.
  * Updated ebuild for latest release.
  * Bugfix ;)
  * Updated ebuild for latest release.

== Release 0.1.25
  * Feature: gemset now displays in info. Bugfix: 'rvm gemset clear' now works as expected.
  * Added unicode char for head. Thanks khaase!
  * Bugfix: install gemset renaming ready for next release.
  * Bugfix: % separator for migration of gemsets.
  * Maglev version 23101.
  * Now using @ as separator :/ ::twitch::
  * Bugfix: Bugfix fixed.
  * Bugfix: If rvm_ruby_gem_home is not set, attempt to set it.
  * Bugfix: Removed extraneous }
  * Bugfix: Properly extract the ruby string for gemset use.
  * Feature: rvm_gemset_separator. Now with '+' as default. Install renames old gemsets. To keep old '%' then export rvm_gemset_separator='%' in ~/.rvmrc.
  * Bugfix: slow the insane logic down.
  * Performance: Use GEM_HOME instead of going through gem in rvm-prompt to gain gemset. Thanks priit!
  * Bugfix: 'rvm benchmark myscript.rb' works again.
  * Added --gems flag for uninstall/remove.
  * Updated ebuild for latest release.

== Release 0.1.24
  * Bugfix: Available packages are now detected correctly, thanks apotonick && NilsH for letting me know about it.
  * Removed global caching scheme in preparation for something sweet.
  * MagLev now 1.8.7 w00t! (23082)
  * Merge branch 'master' of git.overnothing.com:rvm
  * Updated zlib version. Thanks bierbaum.
  * Added a use to rubygems setup.
  * Crossing my legs and hoping not to get screwed.
  * Bugfix: unset rvmrc flag after create.
  * Thanks Wilson!!!
  * 'rvm gemset string' for consistency
  * Display gemset by default in rvm-prompt.
  * Added initial unicode concept for rvm-prompt. Thanks burke!
  * Removed --all.
  * Improved gemset and usage messages.
  * Bugfix: when use --create flag gemsets no longer complain.
  * Comment out some legacy cli items. Cleaned up the CLI help a bit. Thanks dreamcat4.
  * Fix typo in list known for 1.8.6 version. Thanks drewolson.
  * Merged in hellopatrick's patch for MacRuby. Thanks hellopatrick.
  * For JRuby s/kenai/org.s3.amazonaws/g. Thanks nicksieger.
  * Added ruby-head to 'rvm list known'. Thanks takkanm.
  * Rubinius rc3. Thanks Renaud (Nel) Morvan.
  * We have to practice safe sed now that BSD is out there.
  * Better non-interactive operation (color terminal interaction).
  * Try this one Pistos.
  * The spaces for 'readability' have annoyed me long enough.
  * Try that Pistos.
  * Bugfix: only chmod when installed as user.
  * Updated ebuild for latest release.

== Release 0.1.23
  * Bugfix: Ensure PATH includes gemset path when gemset is used.
  * Bumped MagLev version.
  * Moved the root check up higher.
  * Less agressive with the cache linking.
  * Only do the gem cache dance if a user.
  * Bugfix: Reflect on the action for packages.
  * Fix 1.8.7, ensure pathname2 is installed.
  * Tarball not zipball.
  * Updated ebuild for latest release.

== Release 0.1.22
  * Bugfix: Check for rvm_ruby_gem_home and set accordingly. Additionlly don't append %gemset to the existence check, it will already be in the gem home.  Thanks mattdenner.
  * Updated ebuild for latest release.

== Release 0.1.21 - Many gemset bugfixes.
  * Bugfix: rvm gemset delete now works as expected.
  * Bugfix: 'rvm gems use X' now properly sets up all env vars.
  * Bugfix: 'rvm gemset delete X' now works again.
  * Bugfix: 'rvm gems use X' uses X again :)
  * Bugfix: 'rvm gemset use X' will not double X. Bugfix: 'rvm gemset use Y' will no longer display an error message about the ruby string.
  * Feature: rvm_gemset_create_on_use_flag=1 in ~/.rvmrc
  * Bugfix: s/gems/gemset/ in error messages.
  * More ironruby progress.
  * Or maybe not.
  * Ironruby might work now.
  * Progress with ironruby...
  * This is the way it *should* be however ... no comment...
  * Bumped ironruby's version to 1.0-rc2
  * Bugfix: libraries has been moved to package.
  * Cleaned up CLI readme slightly.
  * Added full path to md5 on Darwin in fetch. Thanks shigeya.
  * err ::cough:: /usr/ ::cough::
  * Full path to OSX installer for macruby. Thanks shigeya.
  * Updated ebuild for latest release.
  * Bugfix: Fix /sbin/md5 for Darwin based systems. Thank you very much shigeya!
  * Bugfix: 'rvm package ....' under zsh.
  * Updated ebuild for latest release.

== Release 0.1.19
  * Updated mono package function.
  * Rounded out new package feature.
  * New API: 'rvm package {install,uninstall} {openssl,zlib,readline,iconv,etc...}'
  * Found that blasted missing 's'.
  * Bugfix: gemset not gems in set script. Thanks drewolson.
  * Initialize.
  * Source the utility functions.
  * Bugfix: Function naming error.
  * chmod certain scripts during install.
  * Make libraries executable.
  * Export in the examples.
  * Check for existance before grepping.
  * For root installs, use the rvm_path for global gem cache.
  * Bugfix: Libraries output no longer occurs when rvm is sourced.
  * Bugfix: Don't source libraries, it's now external. Thanks Jimmy Baker.
  * Merged Pisto's ebuild update.
  * Adjust where rvmrc gets loaded for package managers.
  * Advise users to get head often via 'rvm update --head'.
  * Fixed a tyop in examples/rvmrc.
  * Only do 'make' not configure for JRuby < 1.4.
  * Bugfix: For set/do actions if only one ruby is specified only do that ruby. Bugfix: when -S is used don't quote the args, thanks to aslakhellesoy.
  * Bugfix: missed a spot.
  * MagLev version 22907.
  * Added 'rvm seppuku' in honor of tsykoduk who can't spell so it saved his life.
  * Bugfix: 'rvm_gems_select' -> rvm_gemset_select
  * s/gems/gemset/g Thanks everyone for such a decisive vote.
  * Defaulting 'rvm list' to 'rvm list rubies'.
  * Do not try and use log script during implode after removal :).
  * Bugfix: global gems cache setting is now exported.
  * Enhanced the error message.
  * Bugfix: exit not return from script. Thanks TecnoBrat.
  * Added tracability to extracted set actions.
  * Added tags file to gitignore.
  * Heh... might need that.
  * tyop fix for preifx.
  * Made install message about the return statement more clear.
  * Moved 'do' actions to external script (set). Refactored to allow for rvm_prefix for package managers.
  * Bugfix: Show gemset for do actions.
  * Adding ebuild for rvm-0.1.18

== Release 0.1.18
  * Renamed sticky-gems to sticky
  * Removed rvm_path code from installer which should not be set during install. Install is 'black and white'
  * Feature: Now you can empty any gem dir, not just for a gemset.
  * Was too agressive with last commit. We still want to use gemsets :-p
  * Bugfix: GEM_PATH now gets correctly set for rubies without an actual 'version'.
  * Removed warning message, was in the wrong place.
  * Corrected caps of GemStone in readme.
  * More work on gems actions. Fixed capitization of GemStone. Added maglev-head to 'rvm list known'
  * Bugfix: removed double negation.
  * Bugfix: properly detect a ruby string interpreter component.
  * Feature: 'rvm gems create'
  * Added error handling to __rvm_strings (thanks dreamcat4). Began working on the new gemset interface.
  * Adjusted wording from --all to known for rvm install.
  * Feature: New list functionality. Feature new strings functionality.
  * Upgrade installers to rubygems 1.3.6
  * Make the rvm rubies subcommand more helpful
  * Added installation warning when 'return' is detected in .bashrc.
  * Adding ebuild for rvm-0.1.17

== Release 0.1.17
  * Added latest maglev md5's
  * Bump maglev version to 22891.
  * Do not install rubygems for ruby-head.
  * What is with me and my inability to spell?
  * Tweak path logic slightly.
  * 'rvm update' no longer attempts to install from a gem. Now downloads and installsthe latest stable release tarball.
  * Adding ebuild for rvm-0.1.16

== Release 0.1.16
  * Bugfix for the last Bugfix ;)
  * Bugfix: Search global path for 'do' actions.
  * FreeBSD deviates from the norm just like OSX :)
  * 'rvm gems import/export' instead of 'rvm gems dump/load'
  * Feature: 'rvm gems copy X Y', thanks to my UnderpantsGnome.
  * Bugfix: Installer fixed again.
  * dirname of course!
  * change to the location of the install file.
  * Added loading of rvmrc before path calculation.
  * Removed source_path using $0
  * Adding ebuild for rvm-0.1.15
  * RVM Release 0.1.15
  * Allow --sticky_gems from command line.
  * Bugfix: better gem command detection.
  * Adding ebuild for rvm-0.1.14

== Release 0.1.14
  * Bugfix: careful now.
  * Stricter checking.
  * Bugfix: Missed a spot for global gem cache.
  * Ensure symlinks are correct.
  * Refactored global gems cache to be located in $HOME/.gem/cache/
  * Bugfix: Remove archive if it fails checks. Feature: Initial bundler support.
  * Bugfix: rvm gems delete.
  * Updated yum based notes. Thanks RubyPanther.
  * Feature: 'rvm X --rvmrc'.
  * Adding ebuild for rvm-0.1.13

== Release 0.1.13
  * Adjusted install message to be more explicit about the return. Adjusted rbx's installer.
  * Turns out it was the previous 1.8.7 install that was jacked, not the rbx installer.
  * Bugfix: remove spaces in filenames for rvm gems load.
  * Tweaking rbx install.
  * Slowly improving gemset functionality.
  * court3nay is correct, we want \s
  * Bugfix: rvm gem install t* now works again ;)
  * Removed empty file.
  * Install now exits on failed patch. Error command output tweaked.
  * Adding ebuild for rvm-0.1.12
  * Patch with p0
  * Bugfix: rvm install X --patch Y now patches :)
  * Feature: Cleaned up 'rvm list'
  * Add some more output so that you know what's going on when a gem is already installed.
  * Bugfix: 'rvm gems load X' as well as 'rvm gem install Y'.
  * Oh man, that was a very sneaky lil buggar...
  * Sometimes I am so dense that I myself don't realize that I'm completely daft :/
  * I suffer from accute mental deficiency :(
  * Need more caffene...
  * A refactoring we will go... A refactoring we will go...
  * Perhaps it's better to just let things go sometimes.
  * Two installs for the price of one
  * Bugfix: 'rvm gem install X' should now actually install X
  * Altering how gem path & home are passed for gem install.
  * Switch the unsetting of the patch specification to the global variables.
  * Refactored libraries code. Added rvm_ruby_patch exports.
  * Removed completion script.
  * Bugfix: rvm reset now clears default properly.
  * Bugfix for 'rvm gem install X' dealing with GEM_PATH setting.
  * Added proxy ability for rubies fetching. Thanks Jadefalkner.

== Release 0.1.11

== Release 0.1.10
  * Bugfix: Fixed tyop in variable name. Fixed extra space issue.
  * Bugfix: PATH correction. Thanks UnderpantsGnome.
  * Bugfix: Fixing the last Bugfix correctly.
  * Bugfix for zsh on gems load. Began adding 'rvm install mono' - not done.
  * Bugfix: Macruby 0.5

== Release 0.1.9
  * Bugfix: 'rvm install macruby' now installs 0.5 instead of nightly build.
  * Is a direcotory and not a symlink.
  * Fixed pathing for mput.
  * Added test if directory is empty.
  * Bugfix: globbing in zsh is unsettling.
  * Documentation updates.

== Release 0.1.8
  * Bugfix: Separate directory and symlink logic.
  * 1.8.6-p399 now default.
  * Removed tracing.
  * Bugfix in site docs, thanks to wmadden.
  * Bugfix: rvm gems load now properly skips gems that are already installed.
  * Wow, that was a challenging bugger to track down.
  * Updated CLI help with more information. Bugfix: rvm gems load now works again. Feature: rvm gems load now installs gems very fast from cache.
  * Added shell to output.

== Release 0.1.7
  * p398 is now default for 1.8.6. Thanks Kirk Haines.
  * Removed '--no-rdoc --no-ri' as default. Set rvm_gem_options in .rvmrc if desired.
  * Added ebuild for 0.1.6.
  * Added GEM_PATH to info output.
  * Bugfix: Use the proper variable for global gems paths.
  * Bugfix: Removed extra slash from shebang for hooks, thanks haruki_zaemon

== Release 0.1.6
  * Update default 1.8.7 to p249.
  * Thank you Pete Nicholls.
  * Bugfix: Ensure that cache directory exists.
  * Added ebuild for version 0.1.5 .
  * Merge branch 'master' into ebuilds-nice
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.1.5
  * Careful not to nuke system gems cache.
  * No! the other left!
  * Bugfix: So system rubies matter? ;)
  * Updates to all ebuilds, including 0.1.3, 0.1.4 and "edge" (git) versions.
  * Updates to all ebuilds, including 0.1.3, 0.1.4 and "edge" (git) versions.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of github.com:Pistos/rvm
  * Update maglev's version to 22816.
  * Bugfix: fun with zsh ;)
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.1.4
  * Added filesystem permissions check to rvm debug.
  * Ensure that %global gets into path.
  * Tweaked verbage.
  * Bugfix: global gems dir, no blind move.
  * Feature: cache md5 sums on successful download.
  * Global gem cache :)
  * Features:  %global default gem set.  symlink of each ruby's interpreter default gem set to ruby_string/lib/ruby. Thanks UnderpantsGnome for the %global idea.
  * Site update.
  * rvm now creates symlinks to gem directories in rvm_ruby_home/lib/ruby/1.8 for example.
  * Add patch dependency notice.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bump LLVM version.
  * More tweaking of rvm_path for Pistos.
  * Mental Breakdowns for fun and profit.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * putting it back :)
  * Merge branch 'master' of github.com:Pistos/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Adjusted default path again.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Adjust order of defaults loading.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Moved scripts detection code, added defaults.
  * Thanks Justin Smestad
  * Thank you Justin Smestad for your support!
  * Trying adding in a default fallback for rvm_path.
  * Upgrade MagLev version.
  * Run notes from cwd.
  * Added rvm_scripts_path to install block.
  * Site updates.
  * Honor rvm path for irbrc.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Ensure log directory exists for nested logs.
  * Added rvm irbrc processing to post_install.
  * Merge branch 'master' of github.com:wayneeseguin/rvm

== Release 0.1.3
  * Added ebuild for version 0.1.2.
  * Added Maglev 22780 checksums.
  * Added MagLev 22780 Added rubygems update when new ruby gem home is created.
  * Feature: 'rvm install ruby-head'.
  * chose MRI SVN repository when install with head option
  * Merge branch 'master' of github.com:Pistos/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.1.2
  * Site update.
  * Bugfix: better handle ruby log paths.
  * Bugfix: Append to log when running a command.
  * Bugfix: directory creation during installer.
  * Added comments for all utility functions.
  * Added 'rvm rubies' for use with scripting.
  * Use the redist-libs as the source folder for Ruby libraries when copying IronRuby files after building.
  * Fixed a mistake in the manual merge performed in commit d471bb9.
  * Fixed a regression introduced after commit 12221fe that broke the recognition of a proper mono version to build IronRuby from the Git repository.
  * updated to Ruby Enterprise Edition 1.8.7 2010.01
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Adjusted wrapper scripts.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * MagLev update, symlink gemstone dir.
  * Pedantic formatting for jruby in rvm list.
  * Consistent formatting.
  * maglev is *always* x86_64
  * Bugfix: don't exit out when mostly done with MagLev install.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.1.1 - bugfixes.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Removed sourcing of .rvmrc / etc/rvmrc.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Tweaking init for install.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Add env vars to install trace.
  * Enable install tracing.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: destinkerifying.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: smelly elif.
  * rm -rf rm -rf.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Moved stored system/default into config/ from rvm_path
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Only show manual instructions if not installing as root.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Quick, pull your pants up the boss is comming
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Added another sanity check.
  * Updated binscripts/rvm
  * Bugfix: 'rvm install jruby' actually works now :)
  * Bugfix: 'rvm install jruby' now sets the correct archive extension.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of github.com:Pistos/rvm
  * Bugfix: maglev-head added demo key.
  * Site update.
  * Updated sha1's for MagLev on Linux.
  * Copied /usr/portage/skel.ebuild for first ebuild.  No changes yet.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Updated rvm-prompt to be more 'bare'. Thanks Pistos :)
  * Bugfix: issue a warning and point to docs when 'rvm gems' without arguments is used.
  * Added gems to help output, thanks technicalpickles.
  * Minor installer tweaks.
  * Added 'rvm_sticy_gems' setting for ~/.rvmrc file. Tweaked maglev-head.
  * Updated directory creations.
  * More updates for maglev-head.
  * Added new GemStone sha1. Fixed a logical bug with maglev-head install.
  * More MagLev tweaking. Now workign on getting 'maglev-head' working proper.
  * Added maglev-22725 sha1.

== Release 0.1.0
  * Added maglev to usage output and list.
  * Updated installation notice
  * Silly rabbit... debugs are for developers...
  * Shebang adjustment. Site update.
  * Added migration piece for rubies so that people aren't caught off guard like with the gem directory change.
  * Updated MagLev version. Fixed a few items I missed with last commit.
  * Initial refactoring of rubies into $rvm_path/rubies
  * Final pre 0.1.0 release allowing for full MagLev functionality with gem install.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Minor tweak for Pistos.
  * Silence gemstone check for MagLev.
  * Bugfix: Only start stone for maglev once.
  * Updated MagLev verison.
  * Bugfix: 'rvm gems load' now works under zsh as well :/
  * Fixed a tyop
  * 'rvm install ree' now properly extracts with the correct extension.
  * More work on MagLev support. Added check for running gemstone. Added check for setting version based on ruby string digits piece.
  * Tweaked notes to include release name on Linux.
  * Update 1.9.1 to default to p378.
  * Bugfix: removed z in tar's where piping through gunzip. Thanks to jfsworld.
  * Added 1.8.7-p248 md5.
  * If rvm_project_rvmrc=0 then don't even hijack cd.
  * Fixed maglev gemstone extraction
  * For now always nab gemstone.
  * Removed extra }
  * Updated to new MagLev url scheme.
  * Updated maglev urls.
  * Changed maglev to download tar.gz
  * Switched tar extractions to work on Solaris. Updated install doc.
  * Added start to use maglev.
  * Missing [
  * Only extract gemstone on head.
  * Only download gemstone for -head version.
  * Minor bugfix.
  * Initial working maglev, no head.
  * MagLev precheck script working.
  * added maglev prereq script.
  * Initial working 'rvm install maglev'. Several things need to be done before releasing maglev.
  * Bugfix: syntax error, daft man coding.
  * Bugfix: Extract on force if already extracted. Beginning maglev code.
  * grr.
  * Bugfix: rvm gems load for path to gem file no longer emits an awk error.
  * Thank you very much, Robert Hunter!

== Release 0.999, getting very close to 0.1.0
  * Added some exit points to rbx install for error cases.
  * Site updates.
  * Upgraded rbx. Several other fixes and patches. Thanks awesome users!
  * Site Updates.
  * Removed the --jit from usage which is no longer used. Use --enable-llvm instead.
  * Feature: sticky gem sets are now disabled by default. Set 'rvm_sticky_gemsets=1' in ~/.rvmrc to enable.
  * Bugfix: rvm gems delete should now work. Thanks jfsworld!
  * Bugfix: MY_RUBY_HOME in default file greps were adjusted since export was moved to beginning of line. Thanks jfsworld.
  * Bugfix: rvm install rbx/rbx-head.
  * Updated install message for zshrc instead of zshenv.
  * Altered rbx llvm code based on feedback from Evan. llvm is now default so the option for rbx is --disable-llvm.
  * Bugfix: 'rvm default' now works as intended. Thanks rolfb.
  * Switched to using match script inside mono install section so that older bash shells can still run. Thanks tibra.
  * Bugfix: Don't fetch version when --head is specified for macruby.
  * Abort macruby-head installation if install_source exited with error code.
  * Make llvm building opt-in for macruby via --enable-llvm flag (for now).
  * Add libraries to manage script.
  * How'd that get in there?
  * Propigate default through selector.
  * Propigate default from CLI.
  * Bugfix: install to exit upon encoutering it's first error.
  * Tweaked install message slightly.
  * Bugfix: rvm gems delete now works again.
  * Bugfix: 'rvm gems name' works now.
  * Feature: 'rvm gems clear'
  * Bugfix: rvm gems list. Thanks jpalardy.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Added export of rvm_hooks_path. Thanks jpalardy.
  * Corrected a few typos in the site's content
  * Bugfix: s/rvm_dir/rvm_path/g
  * Thank you Jack Dempsey.
  * Bugfix: always hit ruby for version string instead of current binary for 'do' actions.
  * Updated 1.8.7 in rvm-list
  * Changed default 1.8.7 to p248.
  * Changed default 1.8.7 to p248.
  * Thank you Jonathan Palardy.
  * Added git-core to apt based hosts notes message. Thanks racan.

== Release 0.0.99
  * Added rvm source script test for website.
  * Adjusted formatting of 'rvm list'.
  * More tweaks to install message.
  * Feature: './install' no longer touches rc files. Pass --auto to installer in order to have it touch the rc files. Thanks agib.
  * Option: rvm_gem_options ; default: --no-rdoc --no-ri
  * added extra sanity check to gem install
  * When root created default AND symlink both. Fall back to /usr/local/rvm/default when selecting default.
  * Extracted hoooks to external script. Improved cd logic.
  * Added warning to install & documentation not to return from .bashrc.
  * Bugfix: jruby-* in rvm list now correctly does -v on the ruby itself.
  * Bugfix: if a file name is given during dump, honor it.
  * changed exec to eval for rvmsudo.
  * Bugfix: only create ./log if using it.
  * Bugfix: whoops, those are variables?
  * corrected variable placement.
  * Adjusted prefixing for rvmsudo.
  * Added line padding around 'rvm --version'
  * Bugfix: when no gem home set rvmsudo should not fail.
  * Return to original directory after update.
  * Added spaces before & after logging messages based on Yehuda's recommendation.
  * Merge branch 'master' of git.overnothing.com:rvm
  * Detect interactive vs non-interactive and adapt logging output based on interactivity. Thanks agib & egyp7.
  * HOME rvm overrides system.
  * Don't mkdir on specs
  * Let's try initializing rvm's variables.
  * Switching to a different tactic.
  * Silence errors when detecting.
  * Merged.
  * Attempting to fix the detection of an installed gem.
  * Tweaked gem installed test.

== Release 0.0.98
  * Added optional trailing slash. Thanks dreamcat4.
  * Removed quotes from regex.
  * Working on adjusting the installer with dreamcat4
  * merged an extract of dreamcat4's commit
  * Manually merged nrk's patch for BASH_REMATCH check.
  * Manually merged nrk's patch for pwd fix.
  * Manually merged fistfvck's commit 949ca1402f1d8fb491e7eafdf661205da388123a.
  * Added a missing LF for notes related to JRuby on systems running pacman.
  * Tweaked initializer based on dreamcat4 suggestions and some cleanup.
  * Added messages for IronRuby to install notes.
  * Added IronRuby to the README.
  * Support for building and installing IronRuby from the official git repository (Mono >= 2.6 is required).
  * Merge branch 'master' of git.overnothing.com:rvm
  * Feature: rvmsudo X for executing X in context of current rvm selection.
  * Bugfix: adding HOME .profile to correct zshenv.
  * Added mkdir -p to install script for rvm paths.
  * Bugfix: 'rvm gems load' works again as well.
  * Bugfix: no more double extraction for jruby.
  * Bugfixes: rvm install jruby.
  * switching more back ...
  * Added message to 'ant dist' build line. Reverted more items.
  * Bugfix: ant dist on jruby-head.
  * Put back rvm-prompt :/
  * Bugfix: jruby always run ant.
  * Added JRuby message to install notes.
  * Added --{disable,enable}-{llvm,jit} cli flags.
  * Bugfix: JIT logic.
  * More tweaks to rvm rbx install.
  * Nuked some unnecessary codez.
  * That should about do it for 'rvm install rbx'
  * Progress with rbx however... how do you specify install target for package?
  * Trying a different install on use approach.
  * Trying a different install on use approach.
  * Take that Scyllinice!
  * Well this is fun, switching back around.
  * What trace? I see no trace?
  * Bugfix: Adjusted ruby string interpreter matcher.
  * Added debug messages to gems actions.
  * Bugfix: properly restore rbx's ruby string.
  * Bugfix: rvm_install_on_use_flag=1 in ~/.rvmrc works again.
  * switch from $interpreter/$versin to $ruby_string for gem dirs.

== Release 0.0.97
  * Documentatino updates.
  * Bugfix: 'rvm X gem install Y' now works, w00t
  * Yes folks, zsh IS better at emitting a stack trace :)
  * Bugfix: Installing gems via 'rvm gem install X'
  * Bugfix: I just found out the which command on OSX has different options than on Linux :/
  * Merge branch 'fix_rvm_ruby_do'
  * Removed debug statements.
  * Bugfix: account for plain old ruby in the ruby string :)
  * Bugfix: variable has regained its $
  * Bugfix: 'rvm remove reeee' no longer tries to remvoe all rubies.
  * Feature: Use default set in $HOME first then ruby path.
  * Bugfix: only run exract for jruby if not installing jruby-head.
  * unset loaded flag during reload.
  * switch .profile and rvm sourcing order
  * re-feature: Added back the sourcing of .profile if it exists. Began cleaning up bash scripts.

== Release 0.0.96
  * Features: rvm X --editor : creates rvm_path/bin/editor_X symlinks rvm X --passenger : creates rvm_path/bin/passenger_X symlinks rvm X --symlinks smurf : creates rvm_path/bin/smurf_X symlinks
  * Merge remote branch 'origin/fix_rvm_ruby_do' into fix_rvm_ruby_do
  * fixed 'File Not Exist' error, when rvm_do.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Removed --enable-shared as default on recommendation of Aman Gupta (tmm1).
  * Rubinius: LLVM is enabled by default; flip --enable-llvm to --disable-llvm
  * Initial support for IronRuby's binaries. NOTE: the current download URL is temporary and it might change in the future.
  * The user might not have curl installed, so we should prompt to install curl in the notes section
  * Bugfix: rvm -e 'puts 6 + 7' should now work.
  * Bugfix: silence error output from ls.
  * Thank you Scott Clausen!

== Release 0.0.95
  * Feature: rvm now behaves the same way when logged in as root and user. To set a system wide default ruby now do 'rvm X --default' when logged in as root
  * Bugfix: --enable-shared not --enable_shared, thanks saimon!
  * Minor version bump.
  * No longer run irbrc on select.
  * Minor adjustment, --enable-shared.
  * Default compile flag is now --enable-shared=yes unless overridden with -C ...
  * Bugfix: 'rvm list' now shows proper architecture strings.
  * Bugfix: silence another which ruby call and also test for executable  on system ruby.
  * Bugfix: Check proper directory and script for root install, additionally ensure rvm_path is a directory before attempting to load rvm.
  * Minor version bump.
  * Set PATH after symlinks for zsh to rehash.
  * Bugfix: 'rvm gem install X' works again after extracting gem actions to a external script.
  * Have gems load use current set / exported environment.

== Release 0.0.92
  * red is the new green ;)
  * Only call colors once per color. Set rvm_ruby_gem_home if it is not set.
  * Set gem_args.
  * Missed a rename with last commit.
  * Properly reflect on the gems(et) file.
  * the external gems methods should use the environmental ruby.
  * Sometimes, I see dumb people. Then I realize I'm looking in the mirror. :/
  * Who commented out that shift? :)
  * re-added load action
  * Bugfix: 'rvm gems load' once again loads the gems(et).
  * Bugfix: export configure flags for manage script.
  * Added code to get 1.8.5 to compile on all systems, including ones with newer readline & openssl :) Thanks khaase!
  * Feature: Added post-gem-install message. Thanks tmm1!
  * Default Change: per-project rvmrc code to switch to default/system on exit is now opt-in instead of opt-out.

== Release 0.0.91
  * Bugfix: 'rvm update' now tries current ruby first. Bugfix: 'rvm install' does not imbecillically use the same code as initialize and startup.

== Release 0.0.90
  * Bugfix: rvm gems(et) commands now work again.
  * Site Updates.
  * Bugfix: rvm install X for libraries now works again, broken in 0.0.89
  * I am so incredibly daft sometimes :(
  * Over zealous
  * Attempting to improve rvm_path logic.

== Release 0.0.89
  * Feature: Monitor files in lib/ and app/ directories. This might need some more polish.
  * Feature: md5 checksums now happen so that archives are not re-downloaded.
  * Bugfix: rvm scripts path looks around now before gettings set if not already set.
  * Site updates.
  * Added user tag ability to rvm ruby strings for future requirement.
  * Site updates.
  * Site updates.
  * Feature: gem actions are now in external scripts.
  * libraries are now uninstallable.
  * Bugfix: check if not null, not for equals 1
  * Added rvm/usr path detection.
  * Added 1.9.1-p376 to rvm list --all
  * fixed 'File Not Exist' error, when rvm_do.
  * If rvm_archflags=1 then set rvm_make_flags_flag.
  * Bugfix: rvm runs extract even if archive already exists.
  * Made __rvm_make_flags opt-in via rvm_make_flags_flag
  * Updated 1.9.1 default patchlevel to 376.
  * Add curl to 'rvm notes'
  * Moved do all case to use shell builtin glob instead of ls.
  * Adjusted for config/user during install.
  * fixed __rvm_update_rvm
  * Bugfix: nailgun now compiles for jruby.
  * Bugfix: JRuby rake & gem now work as expected out of the box.
  * Bugfix: Run extract after package fetches only.
  * Bugfix: moved 'rvm_remove_ruby' into the external manage script.
  * Committing  Rolf's mute button :-p
  * Site update.
  * Thank you Konstantin Haase!
  * Removed trap for zsh.
  * Finished extracting installer to separate script.
  * Site Update.
  * Site update, thanks Erik Hansson!
  * Feature: 'rvm fetch X,Y,Z' works.
  * Minor version bump in preparation for a release.
  * rvm_fetch improvements
  * Began working on 'rvm fetch' function.
  * Site update.
  * Bugfix: Install message no longer shows awk output, notes cleaned up.
  * Adjustment: rvm gems load switched colors and message around to make it more natural.
  * Bugfix: jruby install now correctly symlinks the jbinaries to regular and no longer alter's their shebangs.
  * Removed the run flag.
  * Adjusted the version output during install.
  * Removed a failed attempt at a self aware script ;)
  * Evil slash... begone!
  * Tweaked installer for new binscript.
  * script vs run logic.
  * Clear!.
  * Knit three yank six.
  * Try one pull two.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Provide more information during the installation.
  * In Darwin, explicitly use system's "basename" command.
  * Feature: rvm_symlink_path now overridable and defaults to /usr/local/bin
  * Extracted cd to sorced script.
  * Feature: Project specific rvmrc files now switch back to default and/or system rubies when exiting a project directory. Additionally they can now be toggled off by placing 'rvm_project_rvmrc_default=0' and/or 'rvm_project_rvmrc=0' in the ~/.rvmrc file
  * Bugfix: rbx_url
  * Site updates.
  * Removed debugging flags.
  * Tweaked monitor with a file check.
  * Added monitor page to site.
  * Bugfix: rvm reload now correctly reloads and does not go loopy.
  * Bugfix: break in case? Really? ...
  * Initial thoughts on patch support.

== Release 0.0.86
  * Added a simple bootstrap script to the documentation.
  * scripts/hash now executable in preparation for future use.
  * Bugfix: system for rvm list now shows up properly when exists.
  * Feature: ~/.rvm/config/user now available for user defined settings and defaults.
  * Site updates.
  * Adding config/md5 sum file.
  * Updated examples/rvmrc file to be current for the project. Fixed 'rvm_temp_path' to be 'rvm_tmp_path' as expected.
  * Bugfix: More tweaking of the rvm load.
  * Bugfix: scripts/rvm does not re-source if rvm is already loaded.
  * Bugfix: added missing ; then
  * Site update, thank you Vladimir Sizikov.
  * Added tracability to monitor.
  * Minor version bump after 0.0.84 release.
  * Minor version bump.
  * Bugfix: Be sure to include files right in the test/ and spec/ directory also.
  * Bugfix: 'rvm reload' now works again :)
  * Feature: 'rvm <ruby string> monitor' now works for: rspec,shoulda,test/unit,...
  * Feature: 'rvm <ruby strings> monitor' now works for spec/
  * Feature: 'rvm install rbx' now installs Rubinius 1.0.0-rc1.
  * Bugfix: 'rvm install mput/shyouhei' now clones the proper url
  * Bugfix: shebang line now sets correctly.
  * Bugfix: Correctly set rvm_path for system only installations.
  * Missed a spot for CFLAGS adjustment.
  * Allow CFLAGS and LDFLAGS to be specified by environment.
  * Bugfix: silence error messages from the  command.
  * Site updates.
  * Bugfix: Logic was negated for finding gem command.
  * Bugfix: Silent gems select.
  * Bugfix: subshell not string :/
  * Adjusted spacing for 'rvm notes'
  * Feature: 'rvm notes' now outputs the same notes as spit out during rvm install.
  * We really are not interested in the output of 'which gem' for testing purposes :)
  * Adjusted install message for ubuntu.
  * Added message for list when no system ruby installed.
  * gems select should silently return if gem missing.
  * Added gem check to gems select
  * Alter checks.
  * If ruby & gem do not exist, skip default setting.
  * Skip gem actions with an error message if no gem command found.
  * Bugfix: Added check for source directory during install. Added check for gem existing for the case when no ruby exists.
  * Bugfix: Account for the case where there is no current ruby.
  * Bugfix: Account for the case where there is no current ruby.

== Release 0.0.82
  * Added site/tmp/dependencies to gitignore.
  * Bugfix: installer loading logic.
  * Site updates.
  * Added XCode version & update message to install.
  * Send error & fail messages to stderr.
  * Added array functions.
  * Extracted monitor to external script, will finish implementation later.
  * Feature: Added a few hooks, most importantly ~/.rvm/hooks/after_use
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Altered 'rvm list' output to be more clear.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Removed subshell after nice command.
  * Bugfix: properly copy binscripts to $rvm_path/bin/
  * Bugfix: running -v against an existing script.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Feature: rvm_ruby_mode now propigates to the ruby -v output on the do line as well as the ruby string output.
  * Bugfix: Properly pass mode, do not store in rvm_ruby_args.
  * Feature: Ability to specify a ruby string 'jruby-m1.9' in order to startup jruby with --1.9 mode.
  * Tracing is like divining with entrails!
  * Bugfix: do not unset all variables. Bugfix: Adjust the rvm loading logic.
  * buahahahaah found you you lil bugger! bug ! bug ! ... SQUISH
  * Bugfix: Initialize issue during install.
  * Removed debugging line.
  * Bugfix: Installer actually works now when no rvm is present :)
  * Bugfix: Better return logic on failure from fetch.
  * Much refactoring see PT...
  * Significantly cut down on trace noise.
  * Bugfix: Removed extra /rvm/ in scripts path. Removed external --prefix option.
  * Refactored initialize out of several places into a common script and improved it's logic for handling root installs.
  * Bugfix: adjust rvm_prefix_path and rvm_path to be user overridable and have consistent defaults in both initialize() and install()
  * Applied my new found education on the naming of JRuby :) Thanks VVSiz
  * Minor version bump post 0.0.80 release.
  * Feature: 'rvm list --all' now outputs ruby strings and indicates defaults and has a few extra comments.
  * Support Heroku style '.gems' files.
  * Bugfix: rvm do actions now work with 'system' ruby. Example: 'rvm 1.9.1,system,ree rake spec'
  * Minor version bump after release 0.0.79.
  * Switch to rvm_path instead of hardcoded ~/.rvm.
  * Bugfix: 'rvm gems load' now works for system rubies as well.
  * Strip preceding whitespace.
  * Select 2nd field from output of sysctl.
  * ppc pre-empts 64 bit check.
  * Adjusting make_flags for PPC
  * Don't call make_flags for ree releases, it computes things with it's own installer.
  * Adjusted macruby_nightly latest url.
  * Bugfix: 'rvm specs/tests/rake spec/rake test' now work proper.
  * Bugfix: Strip off trailing 's' for specs/tests when passing to rake.
  * Bugfix: specs/tests CLI.
  * Honor user .rvmrc and /etc/rvmrc settings during rvm install.
  * Lop off path when collecting gem names for gemsync
  * Properly unset vars for rbx install and only call make_flags for 1.[8-9]* rubies.
  * Minor version number bump.
  * Remove ParseTree requirement for rbx, additionally remove %rbx gem set.
  * Bugfix: strip off the t for tag when checking out repo.
  * Bugfix: correct tag selector.
  * site updates.
  * Bugfix: add -eq 1 to test for zsh.
  * Disabling Installer code from rbx for now.
  * Added export of rvm_ruby_string and gem_set_name for selected default rubies.
  * Feature: Export ruby string and gem set name for extrnal scripts to take advantage of them.
  * Feature: Source a .rvmrc file in a directory after changing to it, if it exists.
  * Bugfix: Honor -C configure flags passed via command line.
  * Added back the --host and --build configure options.
  * Bugfix: (sorta) ignore calling self when $* matches completion-
  * Minor version bump.

== Release 0.0.77
  * Bugfix: 'rvm gem uninstall X' no longer errors on --no-rdoc
  * Feature: 'rvm install ree-1.8.6' on Darwin now injects --no-tcmalloc
  * Removed usage of =~ for now :/
  * Switched shebang lines to use /usr/bin/env.
  * Feature: 'rvm install curl'. (For use with curb for example: 'rvm ree ; rvm install curb -- --with-curl-dir=/Users/wayne/.rvm/usr/'). Thanks foca.
  * Minor Version Bump.
  * Feature: Detection of scripts directory vs rvm path.
  * Bugfix: 'rvm gemdir', 'rvm gemdir system', 'rvm gemdir user', etc... now all work as expected.
  * Bugfix: rvm 1.9.1,1.8.6 -S spec spec/hash_spec.rb. Thanks dbussink.
  * More tweaks to Darwin build architecture detection.
  * Bugfix: only honor MacOSX SDK's. Thanks rolfb.
  * Prevent \ interpretation.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Site Updates.
  * fixed symlink path for default-irb/default-gem
  * Feature: Have 'rvm use X' be verbose and output 'now using ruby X' while 'rvm X' not be verbose for scripting (by default). This can be overridden by placing rvm_verbose_flag=1 in ~/.rvmrc to always be verbose.
  * Feature: Cleaned up rvm list, added some color.
  * Bugfix: clear all gems flags when cleaning up variables.
  * Initial SysAdmin root level support -- specficially targeted to hosting environments.
  * Feature: for 'rvm gem install X' add --no-rdoc --no-ri
  * Bugfix: --ree-options should now actually take options.
  * Bugfix: i686 for x86_64 in --host and --build.
  * Skip autoconf step if configure is defined.
  * Adjust how we build llvm.
  * Build llvm prior to building macruby.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Buahahahahahaahahahahaha...
  * Fun with configure.
  * Switched function style in installer and utility scripts.
  * Improved rubygems install code some.
  * Bugfix: 'rvm install 1.9.2' no longer tries to install 'ppreview1' :)
  * Minor version bump after 0.0.73 release.

== Release 0.0.73.
  * jruby 1.4.0 is now default. macruby now only shows up in all list if system is OSX.
  * Minor version bump after 0.0.72 release.
  * Initial jruby-head support.
  * space fail.
  * Fixed up installer based on suggestion by chrisk.
  * Feature: Added macruby to 'rvm list'. Adjusted VERSION to latest jeweler release (yay).
  * Site update.
  * Bugfix: ree installer now a) does not double call make_flags() and b) parses the configure to place -c before each --call.
  * Nice basename idea Chris Kampmeier.
  * Bugfix: Adjusted 'ls' in order to avoid aliases.
  * Make user facing message simpler.
  * Bugfix: adjust svn urls for new ruby string logic.
  * Minor version bump.

== Release 0.0.71: Added macruby & rbx to rvm list. Initial (simple) ruby support.
  * Feature: rbx and macruby now both show up under rvm list.
  * rvm Release 0.0.70: Initial macruby support.
  * Feature: 'rvm macruby' now defaults to the 'nightly' version.
  * Feature: 'rvm install macruby-nightly' now works. Caution: conflicts with beta release, advise using nightly builds.
  * Site update.
  * Added initial ruby support files.
  * Minor version bump.
  * Tweaked version difference message a bit, great stuff thanks docwhat :)
  * Feature: Checks if rvm needs to be re-synced in the shell.
  * Bugfix: 'rvm gemdir' thoughts not completed are best completed.
  * Bugfix: Correctly check for the specification file to see if it is already installed :)
  * Well that was rather embarassing ...
  * Slowly improving gem handling logic.
  * Feature: respect the reported architecture of the host OS on Darwin. Additionally allow the user to override via rvm_archflags in ~/.rvmrc
  * Adjusted jruby download url.
  * jruby RC1 -> RC3
  * Bugfix: We *want* shell expansion of some things :)
  * Bugfix: irbrc loading code, thanks yury!
  * Bugfix: 'rvm system' now works as expected.
  * Site updates.
  * Respect any previous configure flags.
  * Bugfix: Ruby now compiles more explicitely as i686 on OSX 10.
  * Bugfix: 'rvm gemdir' now works again, thank you Tony_.
  * Added extra trace output.
  * tyop fix. Thanks coderpath.
  * s/checkout/update/. Thank you rubys!
  * Bugfix: svn checkout is ... fascinating.
  * Subversion revision tweak.
  * Adjusted download/clone/checkout messages, thank you rubys.
  * Bugfix: Check for head flag for download url.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Bugfix: (again) 'rvm 1.9.1 --head'. Thank you rubys.
  * Fixed use of RUBY_ENGINE -- doesn't exist in ruby < 1.9
  * Rewrote __rvm_ruby_string to be a) flexible b) handle errors better and c) far less complex! Thanks for the idea, Chrononaut!
  * Site update.

== Release 0.0.66
  * Bugfix: 'rvm 1.8.7%gemset' now works again (broken in last commit).
  * Bugfix: 'rvm 1.8.7-p160' now works.
  * Bugfix: 'rvm 1.9.1,ree,jruby benchmark some_code.rb'
  * Added missing file scripts/irbrc.
  * Moved usage out to readme.
  * Patches: Thank you Thomas Ritz. Altered irb files to use env vars.
  * Feature: Use a common irbrc for all installations for easy upgrades.
  * Bugfix: 'rvm 1.9.1%somegem ; gem install wirble ; rvm 1.8.7 ; rvm gems delete 1.9.1%somegem' now works properly.
  * Feature: IRB prompt mode is now stored in :RVM instead of :DEFAULT.
  * Bugfix: 'rvm gem install X' now works.
  * Put PAGER code back. bad monkey, careo, bad bad bad monky :-p
  * Site updates.
  * Bugfix: Do not respect the users PAGER setting as it may break rvm help.
  * Switch back from bash native subsitution.
  * Minor version bump.
  * Adjusted rvm debug to output information useful when debugging issues on OSX.
  * Added --archflags and --sdk, as well as configurable via ~/.rvmrc
  * Switching rbx to use the new installer.
  * Bugfix: Use 64 bit for SL and later, 32bit for previous.
  * Bugfix: tyop, thank you hsbt
  * Use *both* archflags for Darwin.
  * Bugfix: Do not rely on 'ls -t' instead use sort and tail.
  * Bugfix: -S and -e now work properly again. Removed --script and --execute options as they do not appear in ruby.
  * Move reset of configure to all variable reset.
  * Bugfix: 'rvm remove X' no longer tries to install after removing. Feature: 'rvm remove X' now takes a full rvm selector string. Minor version bump.
  * Site update, now officially publishing to gemcutter.org only.
  * Feature: 'rvm 1.9.1-r25443' now works.
  * Site update.
  * Upgraded ree default version. 63 commands, 384 assertions, 384 passed, 0 failed..
  * Applied patch for shyouhei 'mput' ruby
  * Bugfix: 'rvm install 1.9.1 --rev 25443'
  * rvm-prompt has been rewritten to be flexible.
  * Bugfix: 'rvm 1.9.1-head'
  * Site update.
  * Bugfix: 'rvm install 1.9.1-head'.
  * Minor version bump.
  * Bugfix: Removed __rvm_reload
  * Feature: Restore cwd after rvm update. Bugfix: 'rvm update' should work again.
  * Minor site wording tweak.
  * rvm Release 0.0.62 (See PT for information).
  * Bugfix: properly extracting of gem names & versions
  * Escape paren in regex.
  * Logic tweak to gems loading.
  * Bugfix: gem name parsing for gemset laod.
  * Missed a spot.
  * Double entendre :)
  * Several bugfixes and features (see pT)
  * Site updates.
  * Site update.
  * Site Update, thank you Brian Hogan!
  * Bugfix: Use rvm_path and do not hardcode .rvm DOH.
  * Adjust to use actual architecture rather than OSX release version.
  * Remember kids, practice safe sed!
  * Date bump.
  * Bugfix: 1.8.* now properly use rvm's installed openssl/readline/zlib/iconv. Major accomplishment tonight, would do a backflip if I could ;) w00t
  * Version bump. Bugfix in btu.
  * Site Update.
  * Regex adjustment.
  * Switching to safer sed patterns.

== Release 0.0.60: gems(et) and other bugfixes.
  * Bugfix: 'rvm 1.8.7-p160' works as intended. 50 tests, 351 assertions, 351 passed, 0 failed
  * Bugfix: install should not replace rvm-prompt location :)
  * Added 2 tests with assertions to cover the last feature checked in.
  * Bugfix: 'rvm gems X' and 'rvm gems clear' now updates the PATH properly for the new gem home.
  * Feature: 'rvm gems clear' now clears the current gemset, resulting to the selected ruby's default gem home.
  * Bugfix: If gem version is not specified, omit it.
  * Bugfix: Respect force flag for rvm gems load if gem is already installed.
  * Bugfix: rvm gems once again properly skips gems that are already installed. Feature: rvm gems load now displays red/green for success/failure of gems loading and surpresses gem's output. Added __color function.
  * Adding blank bundler files to site.
  * rvm release 0.0.59: gems(ets)
  * Site update.
  * Site documentation update, added a few more tests.
  * gemsets now work with the selector and multi commands, w00t!
  * Now have: 40 tests, 339 assertions, 339 passed, 0 failed. Gem Sets working as expected.
  * Feature: rvm gems completely functional! Passing test suite, w00t!
  * Bugfix: rvm gems load
  * Removed debug.
  * Site Update.
  * Site updates.
  * Site update.
  * 'rvm install ree' now works without throwing an error.
  * Bugfix: nasty recursive gem home bug.
  * Bugfix: ree string had an extra ) floating around ...
  * use non-prefixed less for pager default.
  * Updating FAQ - Textmate Workaround
  * So ... I can't count eh?
  * release 0.0.58
  * Bugfix: GEM_HOME is now handled correcty.
  * Switched code to use preferred subshell method.
  * Made test clauses safer from bad input.

== Release 0.0.57: Bugfixes.
  * Bugfix: 'rvm ruby' and 'rvm gem' with no arguments now properly issue an error message.
  * Bugfix: 'rvm update' now works again.
  * Remove debug.
  * Bugfix: nasty recursive gem home bug.

== Release 0.0.56. 'rvm gems X', X in {<set name>, load,dump,delete,name,dir,list}
  * Feature(s): 'rvm gems X'. 52 tests, 443 assertions, 443 passed, 0 failed. ::grin:: w00t
  * Bugfix: basename: missing operand.
  * Fixed the tests.
  * BugFix: ree installer.
  * Use signal trap in order to cleanup when done.
  * Remove wget support, we're going all curl baby...
  * Bugfix: 'rvm --help' no longer tries to shift on an empty array.
  * Removed system ps1 from rvm, no longer necessary with rvm-prompt. More work on 'rvm gems ...'
  * Site updates.
  * Merge branch 'master' of github.com:wayneeseguin/rvm
  * Started working on the gemset ui.
  * Fixes issues with the display of preformatted code.
  * Feature: Partial string matches (for use with do actions). Added btu 0.0.1 and 29/290 tests.
  * Switched rbx to latest llvm compilation method (still using --jit from CLI). Renamed rvm_gem_home to rvm_ruby_gem_home for clarity. Shortened 'ruby-enterprise' to 'ree' for brevity.
  * Allow user to set their archflags in ~/.rvmrc.
  * Date update.
  * Minor config tweak.
  * Site update

== Release 0.0.55: Gemset Bugfix.

== Release 0.0.55: Gemset Bugfix.

== Release 0.0.55: Gemset Bugfix.
  * Bumped 1.8.5 patchlevel to 231.
  * Bugfix: gemsets no longer default to version :-p
  * rvm Release 0.0.54: 'rvm jruby 1.4.1' (currently RC1)
  * Feature: 'rvm gemset delete X'
  * Feature: Detect curent gemset if none given and one exists.
  * Feature: Indicate defaults in 'rvm list --all'
  * Docfix: Added jruby 1.4.1 to 'rvm list --all'
  * Feature: 'rvm install jruby 1.4.1; rvm use jruby 1.4.0. Bugfix: Do not let the dog chase it's tail :)
  * Allow exact specification of gemset file during load.
  * Add basename extraction to test also.
  * Prevent users from specifying full path in gemset.
  * Allow --repository and --url and --repo with the CLI
  * Pass '--repo-url X' to override the repository url used when installing a ruby.
  * If you place 'rvm_ruby_repo_url' or 'rvm_jurby_repo_url' or 'rvm_rbx_repo_url' it will override rvm's urls
  * If you place 'rvm_ruby_repo_url' or 'rvm_jurby_repo_url' or 'rvm_rbx_repo_url' it will override rvm's urls
  * Show gem sources when 'rvm debug' is used.
  * Shift if 'use ruby' sequenece to avoid the ruby triggering do.
  * Summary output is now more readable.

== Release 0.0.53
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: 'rvm benchmark increment.rb' now works with jruby. Site Updates.
  * Added Maz's installer patch. Added imajes rvm_loaded_flag idea.
  * Shortened output.
  * Minor version bump.
  * Patch: Maz, fix extraction logic after archive download.
  * rvm release 0.0.52: rbx fully functional.
  * rbx finally works fully, yay
  * Site modification, switch to haml (yay).
  * Feature: --json,--yaml only output those. Bugfix: Downloader for installs.

== Release 0.0.51: ree 1.8.7
  * ree 1.8.7 is now default.
  * Feature: ree 1.8.7.

== Release 0.0.50: Progress.
  * Bugfix: rvm list.
  * Some more tweaking on macruby.
  * Smoothing out the installs & configuring.
  * using default with no default set is a warning not an error.
  * Bugfix: rvm reset now correctly selects system.
  * Minor version bump.
  * Bugfix: Logical switch on jruby should be and not or.
  * Feature: 'rvm load my.gemset' ; Feature: 'rvm dump my.gemset'
  * re-added install symlink.
  * Fixed some paths, thanks Pistos.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.0.49.
  * Some rubinius tweeks.
  * Feature: 'rvm ree 1.8.7 --head'
  * Indent notes.
  * Symlink rvm-install for next few releases to smooth upgrades.
  * Adding ./install
  * Beginning final overhaul before 0.1.0.
  * Feature: --trace flag to differentiate and augment from --debug flag.
  * Site update.
  * Initial try to check archives
  * patch the remainder of the jruby scripts
  * remove old scripts so that links don't lead to weird resutls
  * Feature: 'rvm --shebang --env inspect x,y,z' to help me help others.
  * Bugfix: system indicator.
  * Bugfix: Correctly use bin_script for rubies. THANK YOU smparkes.
  * Full path for shebang.
  * Back to symlinks.
  * Hardlink after install for jfiles.
  * hard link jfiles .
  * Removed extra chmod.
  * Silence errors we don't care about.
  * Set environment for jgem.
  * Bypass aliases for make.
  * use before doing.
  * Stick with jruby's own rubygems.
  * Skip rubygems and only do update for jruby.
  * Installer now allows for non-interactive installs.
  * Feature: rvm restores selected ruby after performing a multi action. Bugfix: unset rvm_ruby_selector when cleaning up variables.
  * Site update.
  * Site updates.
  * Bugfix: s/=true// for --enable-shared. Thanks Maz.

== Release 0.0.48. Site updates.
  * Feature: 'rvm install/uninstall/remove X,Y,Z...' Updated usage & CLI.
  * Feature: 'rvm system --default'
  * Slowly forward with jruby...
  * Bugfix: rvm install X,Y
  * Removed stray __rvm_select
  * Bugfix: rvm install A,B,C now works.

== Release 0.0.47: jruby + rubydo bugfixes.
  * jruby ::twitch:: jruby ::twitch:: ... working ...
  * After much mental aerobics JRuby is now working.
  * Bugfix: jruby shebang now properly set, yay.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: rvm list for zsh if no rvm sourced in bashrc.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git@github.com:Pistos/rvm
  * Bugfix: /bin/bash instead of just 'bash' in case bash is not in path.

== Release: 0.0.46 Essential installer and other bugfixes.
  * Removed pointless warnings.
  * Patch: For curl, detects if server does not support range command, delete archive, and retry download. Thanks Maz.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: Ruby installs now have gem_env/path and shebang properly injected.
  * Bugfix: Fixed jacked up sed script, thanks Maz
  * Finished removing system_path items.
  * Feature: Clean PATH of rvm instead of storing system path. Thank you Joseph Hsu (jhsu)!
  * Feature: json/yaml to log/summary.json/yaml.
  * Bugfix: 1.9.X rubygems install.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * More cleanup.
  * Cleaned up visuals of rvm-install.
  * Bugfix: Multiple and all for rake X now work. Thank you dbussink
  * Single spec case working.
  * minor version bump.
  * Bugfix: Missing space around test, thanks Maz.
  * Bugfix: Install on use flag works now. Bugfix: existence testing and standard file testing for gem path/hme injection.
  * Never do things in a hurry :/
  * Fix test for 1.9, thanks Maz.
  * Feature: Removed path from system snapshot. Bugfix: test for file in post-install.
  * s/sync/gemsync/g

== Release 0.0.45
  * JSON output reformatted and workign in zsh as well.
  * Bugfix: ZSH yaml fix.
  * Feature: 'rvm install X,Y,'Z works as intended. Bugfix: 'rvm install jruby'
  * Make rvm debug slightly more useful when helping people.
  * Bugfix: 'rvm do' === 'rvm rubydo'
  * Fun with popsicles.
  * Bugfix: gemsync actually works now. Thanks bosie.
  * Bugfix: gemsync :)
  * Added gemsync utility. Thanks bosie.
  * Gem Sync mege with gem dup.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Bugfix: rvm list for system, thanks Pistos/Scyllinice. Initial sync code, thanks bosie.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Silence pushes & pops, thanks darkhelmet & bosie.
  * rbx binary wrappers for gem and rake.

== Release 0.0.44: Install Bugfix, thanks Maz.
  * cp -Rf /
  * cp -Rf :)
  * cp -R

== Release 0.0.43. Features: 'rvm benchmark code.rb', 'rvm rake <task>'
  * Bugfix: 'rvm system' works again with rvm-prompt.
  * Bugfix: 'rvm gemdup system'. Bugfix: 'rvm gemdup user'
  * Unearthed gem of a gem, gem features.
  * gem wrapper now in place.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Added rake to rbx install.
  * Feature: --json Summary.
  * Feature: 'rvm benchmark rubyfile.rb' :). Feature: Summary as yaml 'rvm --yaml rake -T'.

== Release 0.0.42.
  * Feature: 'rvm rake -T' (doesn't have to be just -T ;))
  * s/--enable-pthread=true/--enable-pthread/g
  * Bugfix: patchlevel should respect 'head' and 'trunk' values. Thanks Yehuda.
  * Feature: 'rvm remove' and 'rvm uninstall' are now split.
  * re-enabled macruby against git head.
  * LOL bugfix
  * Moved VERSION.yml to lib/
  * Copy over lib dir on install.
  * Install adjustment.
  * Initial rake/gem code.
  * Set ARCHFLAGS for Darwin.
  * Feature: Merge configure options with user's configure options.
  * minor version bump prepairing for next release.
  * BugFix: Would you like a variable with that?
  * Removed -l flag.
  * Bugfix: patchlevel for ree.
  * Added VERSION.yml to Rakefile, thanks tswicegood.
  * ::twitch::
  * grumble... I just pushed a release :/

== Release 0.0.41: Bugfixes. Thank you community awesome.
  * Bugfix: rake gets installed to gem_home/bin :)
  * Site Updates.
  * Bugfix: ruby_string grep should check rev at beginning.
  * Remove 'j' from 'jgem' call bin script.
  * Bugfix: silence ls. Feature: Extracted duplicate rubydo blocks out to a function.
  * Silence error stream for gem list. Remove Readline comment.
  * Comment out manual readline build for now.
  * Bugfix: unset configure variable. More work on gemset loading.
  * Bugfix GEM_PATH. Thanks Jamie.
  * run bin_script after rubygems install.
  * version bump.
  * Show progress indicators for wget/curl when downloading.
  * Site Update.
  * Feature: skip already installed gem files.
  * Thank you Thomas Kern. Bugfix: correct gem file names for gemset load.
  * s/daft-wayne/wayne/g
  * Subshell output redirect, thanks bosie
  * Cleaning up cli. Updating usage. Bugfix: gemset load.
  * Fun with flags.
  * Search rvm gems cache directories for gem files before hitting the 'series of tubes'.
  * Bugfix: gemset load, thanks bosie.
  * if [ 'zsh' = 'daft' ] ; then s/parameters/configure_parameters/g
  * Send STDERR to /dev/null for cache check with gemset load
  * if [ 'zsh' = 'daft' ] ; do sed -i s/status/result/g ; done
  * Bugfix: Patchlevel sanity checks, thanks sfpyra.
  * rvm Release 0.0.40: Ruby Install Bugfix.
  * setn enable-shared=true
  * Ensure that --enable-shared is used with configure :/

== Release 0.0.39
  * Only use rvm readline if it exists.
  * Silence Z grep
  * Features: ~/.bin/ruby,gem,irb,default-ruby symlinks on --default.
  * Bugfix: patch level. Check for non-existant url and issue error message if so.
  * Moved some cli related functions into rvm-cli script.
  * Removed --disable-shared, how'd that sneak in there :-p
  * Feature: gem update --system after installing 1.9.1
  * Feature: rvm built in readline build support now functional. Bugfix: 1.9 installs properly w/rubygems modify instead of install. Site Updates.
  * Removed warning to allow people to run ruby under passenger as root ;)
  * Bugfix: Rubygems install for 1.9 was not honoring its test. Setting flags for readline compile.
  * Feature: 'rvm update --rubygems' now installs rubygems for the currently selected ruby.
  * Bugfix: 'rvm gemdir system user' now works. Site Updates.

== Release: the .38 special.
  * moving forward with readline.
  * Doc updates, thanks anita-kun.
  * flash messages.
  * Bugfix: use 'trunk' for 'head' / 'trunk' rev. BugFix: svn update if svn repo already cloned. Feature: 'rvm install readline'. Feature: 'rvm install iconv'.
  * Merge branch 'master' of github.com:Pistos/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Typo fix, missing |. removed sudo from iconv install.
  * Added two (as of yet untested) functions.
  * Bugfix: rvm list now shows default ruby correctly.
  * 'default_' -> 'system_'
  * Bugfix: Only shift params if version supplied.
  * Feature: 'rvm update --bin'. Feature: 'rvm update --rubygems'. Bugfix: 'rvm system'. Feature: gemset load/dump extracted to functions. Feature: rubygems install extracted to function. Feature: gemset load now checks for a cached version in gem home before installing, accounts for prefix and postfix, setup for eval flag parameter later.
  * Initial ruby_string function, not working yet.
  * Bugfix: tyop :)
  * Feature: 'rvm update --bin.'
  * Bugfix: 1.9.1 gem command shebang line now proper.
  * Bugfix: missing dollar sign prefix.
  * Feature: -r|--require. Bugfix: GEM_PATH in aux scripts. Began setup of status checks for installer.
  * Skip rubygems for 1.9.1
  * Feature: can now pass 'rvm install 1.9.1 -j 8' to have make -j8 called. Bugfix: shebang line w00t. Added GEM_PATH to aux binaries.
  * Feature: exit status codes propigate out of the rvm command. Feature: -S now eats to the end of the line and works as expected, example: 'rvm 1.8,1.9,jruby,rbx,ree --summary -S rake -T'
  * Added initial -I functionality.
  * equivocate arguments ending in '.rb' to -S
  * Added symlink rvm-install -> rvm-update
  * purty...
  * --summary now works with -S.
  * Bugfix: 'gemdir' command actually works as intended now :)
  * BugFix: Do not blindly adjust profiles, test for adjustment condition first.
  * Bugfix: remove '.orig' sed backup files. Thanks Josh Peek. Now working on --summary for use with -S
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * -C should proxy to -c for rvm.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * rvm <selector> -S <scriptname.rb> now works. Bugfix: ree now uses -C args passed in, Thanks chewie71.
  * Bugfix: irbrc loading.
  * Feature: use now prompts for install. Feature: Added timestamps + commands to logs.
  * Feature: 'rvm reboot'. Cleaning up cli into functions.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * rvm list >> multiruby -v :-p
  * Bugfix: GEM_PATH missed a spot for system. Made version single point of change.
  * Added GEM_PATH.
  * Simply load, not copy user's .irbrc, thanks brainopia.
  * Site Update, prompt.

== Release 0.0.37: Bug! Bug!... Squish!!!
  * Made the currently selected ruby more... obvious.
  * Updated 'rvm list' to include a '*' in front of the currently selected ruby.
  * Inject blank line just before injecting source lines during install.
  * Bugfix: default & sytem selector now work properly.
  * Bugfix: rbx install. Bugfix: Check if user has unzip for jruby installs and show warning if not. Minor site updates.
  * Added prompt to site.
  * Fixed wget test, thank you Maz.
  * Updated site with --dump & --load
  * Remove debug flag.
  * Bugfix: gemset --dump correctly separates multiple versions now.
  * Bugfix: remove system *file* if it exists and is a file.
  * rvm-prompt works when you copy scripts/rvm-prompt to your path now :)
  * Feature: rvm-prompt.
  * Issue a warning message if rvm binaries are called as root.
  * Feature: ~/.rvm/default -> ~/.rvm/system ; ~/.rvm/current -> ~/.rvm/default
  * Bugfix: Correctly specify java/ree messages on install.
  * Added scripts/rvm-aliases and scripts/rvm-functions for 'extra' features. Added gemdo usage doc. Added rake to binaries list. Added initial --dump and --load for use with gemsets.
  * Site Updates.

== Release 0.0.36
  * BugFix: rubydo if interpreter is actually a ruby version number, thanks aaalex.
  * Fix for rubydo, all case.
  * Use current user path instead of default path.
  * Applied PATCH by Chrononaut for install to follow symlink to zshrc.
  * Site update.
  * Bumped version.
  * Fixed an IRBRC bug, thanks danny (dnyy). Updated site faq to advise strongly against using sudo, thanks olegshaldybin.
  * Bugfix: IRBRC not getting set with current. Better setting/unsetting behavior for current.
  * Adjusted else fork's location to be consistent with if above, thanks olegshaldybin.
  * Added GEM_HOME explicit setting to installer, thanks zomb. Site updates.
  * rvm gemdir fix.
  * Playing touchy-feely with some log files.
  * Bugfix: rvm-install not rvm-update.
  * Bugfix: Ensure sure that the log directory exists.
  * Fixed heredoc subshell for zsh :/ ;)
  * Bugfix: ree. Initial rakedo & gemdo, not fully baked yet.
  * Update now merged into installer with extra checks. Temporarily commented out actuLfile.
  * Removed bin/rvm-update.
  * Bugfix: binary install for rake. Began merging update script into the install script.
  * Added rbx head --jit to list --all.
  * rvm Release 0.0.35:
  * Fixed missing binaries issue with Ruby 1.9.2.
  * Bugfix: log file name.
  * Fixed db entries.
  * Site update.
  * default_system_ruby fix
  * Bumped 1.8.6 back to 383.
  * Pushed fix for syntax on Makefile line.
  * Added config dir so we get the db.
  * Renamed rvm-installer to rvm-ruby-installer.
  * Bugfix: missing $, thanks brainopia. Feature: Split out files.
  * Bugfix: Correctly unset RUBYOPT for installer if it is *non empty*.
  * Feature: --re-configure. Added selected variable export to prepare for install extraction.
  * Working on defaults from db hash store.
  * Site Updates.
  * PATH tweek for binaries.
  * Resorting to a semi-colon
  * Adding blank space to irbrc.
  * Bugfix: Added 'current' to selector.

== Release 0.0.34: Bugfix: log_file_name... is a variable :)
  * Syntax check, aisle 3
  * Adjusted default system checks to check if ruby is installed, thanks Maz. Bugfix: log_file_name... is a variable :)

== Release 0.0.33: Bugfix: autoconf logic.
  * Bugfix: autoconf.
  * Bugfix: Correctly handle autoconf.
  * Site update.

== Release 0.0.32: Bugfix: PATH to include user's default path now.
  * Adjusted binary file paths to include the user's default path.

== Release 0.0.31: Feature: rvm list --all Feature: Adjusted rvm_ruby_configure. Feature: rvm update Feature: reset so that system ruby (1.8) is used to build rubinius, which requires parsetree. Thanks manveru. Feature: env/path injection to executables. Feature: Added wget support. Feature: rvm_run function. Added update --head. Bugfix: Exit out of push'd directory when encountering a failure. Bugfix: Made trimming the last : in the path more shell agnostic. Bugfix: Moved logs outside eval.  Thank you metaskills. Bugfix: Adjusted default configure options. Updated some site docs. Thanks mr-interweb. Bugfix: don't shift on use if 2nd parameter is empty thanks mr-interweb.
  * Feature: rvm list --all
  * Bugfix: Exit out of push'd directory when encountering a failure.
  * Added wget support.
  * Made trimming the last : in the path more shell agnostic.
  * Added rvm-run function. Added update --head.
  * Moved logs outside eval.
  * Trying something with the configure line for metaskills.
  * Adjusted default configure options. Updated some site docs. Thanks mr-interweb.
  * Bugfix, don't shift on use if 2nd parameter is empty thanks mr-interweb.
  * Adjusted rvm_ruby_configure.
  * Added 'rvm update' feature.
  * Many variable renames/replacements for line shortening and readability.
  * Added reset so that system ruby (1.8) is used to build rubinius, which requires parsetree. Thanks manveru.
  * Added reset for rubinius which requires 1.8 to install due to parsetree, thanks manveru.
  * Working env/path injection.
  * Applying patch from ujihisa: Fixed installer's behavior. See the details below.
  * Moved svn url block inside the svn if.

== Release 0.0.30 Feature: 1.8.6-p383 is now default. Feature: --set-prompt option for prepending ruby version to prompt (opt-in). Feature: GEM_HOME/PATH to: gem, irb, erb, ri, rdoc, testrb, rake. Feature: install --force option Feature: git support to ruby-install-source. Bugfix: unset variables in default file if not set by default. Feature: rvm_prompt added to defaults file. Bugfix: Path fix. Feature: Ruby Wrapper Script. Bugfix: Log path error messages. Typos in docs. Bugfix: usage to be more clear for --configure option, thanks mikeg1a. Feature: alias '--trace' for '--debug' for rake lovers :)
  * Update 1.8.6 to use 383 as default.
  * Added --set-prompt option for prepending ruby version to prompt (opt-in).
  * Added GEM_HOME/PATH to: gem, irb, erb, ri, rdoc, testrb, rake.
  * Added GEM_HOME to rake binary now.
  * Added --force option for install.
  * Added git support to ruby-install-source. Bugfix: unset variables in default file if not set by default.
  * Adding rvm_prompt to defaults file.
  * Path fix. Ruby Wrapper Script.
  * Working out the make & make install options for macruby.
  * *actually* fixed the log path error messages.
  * Fixed quoting issue.
  * Fixed rvm_ruby_repo_url for macruby.
  * Fixed url for macruby in info.
  * Fixed url for macruby
  * Typo fixes for docs. Working on MacRuby with help from lukeredpath.
  * Updated usage to be more clear for --configure option, thanks mikeg1a. Added alias '--trace' for '--debug' for rake lovers :)

== Release 0.0.29: rvm Passenger Support. (with a gemspec :)

== Release 0.0.29: rvm Passenger Support.
  * Bugfix for $@ with passenger, thanks lukeredpath.
  * Added Passenger Support. Bugfix for error log location notification during installs.

== Release 0.0.28: Reverted installation bin scripts. Two bug fixes.
  * Bugfix for '--configure' thanks Scyllinice
  * Updated site.
  * Updated website.
  * Added unset of rvm_prompt on reset, thanks zmack
  * Reverted the bin/rvm-* scripts to their previous state.

== Release 0.0.27 Feature 'rvm implode' Feature --jit flag to tell Rubinius to build with JIT (RBX_LLVM=1). Bugfix reset should select system only after doing some cleanup. Feature missing variable namespaces Feature exits when install goes badly. Feature  for use with PS1 Feature support for inclusion of user's irbrc, if it exists.
  * Added 'rvm implode'
  * Webssite Update.
  * Added --jit flag to tell Rubinius to build with JIT (RBX_LLVM=1).
  * Reset should select system only after doing some cleanup.
  * Added missing variable namespaces
  * Adding exits when install goes badly.
  * Don't unset rvm_prompt
  * Tweaked user's irbrc inclusion to be more efficient (no variable).
  * Added support for inclusion of user's irbrc, if it exists.

== Release 0.0.26: Several bugfixes. 'rvm default' now uses the current set default or system. 'rvm system' now uses system. Adjusted namespace to be even more discreet. Added rbx for rubinius. Cleaned up usage. Removed install all feature. Made rvm_prompt opt-in via env variable.
  * Gem install/update tweak. Updated setdefault docs page.
  * 'rvm default' now uses the current set default or system. 'rvm system' now uses system. Added bugfix for install/update, thanks Maz.
  * Adjusted namespace to be even more discreet. Updated site docs some more.
  * Add rbx. Adjusted usage.
  * Trimmed down 'rvm usage' some. You don't need an 'Installation' section if you are using 'rvm usage' ;)
  * Bumped version #'s and updated date. Removed usage for install all.
  * Now exporting 'rvm_prompt' env var for use with prompts, use if you like.
  * Make prompt feature 'opt-in' :)
  * Removing 'install all' feature.
  * Third time is a charm? :)
  * Another bugfix for install all, thanks Peter Cooper.
  * Bugfix for install all, thanks Peter Cooper.
  * Tweaked install all. Updated site docs some.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.0.25. 'Major Nerdon'
  * jruby HEAD working.
  * Finished initial revision of rubydo.
  * Added an extra line to the output.
  * Path now updates to display currently selected ruby version. Small bugfix in update thanks to Maz.
  * Simplifying install & update. Added message for MacRuby.
  * Added defatults cache file.
  * Added rvm-cache for string storage (defaults).
  * Added ability for more than one --configure option :). More progress with macruby.
  * Initial Rubinius support. Updated Thanks.
  * Initial macruby code, had to stop testing because I could not get macruby compiling :)
  * Named releases, named svn tags, svn revisions, svn head for 1.[8-9].X.
  * Initial tag usage functional, thank you Kirk Haines.
  * Bugfix: install all should not try to install 'REE 1.3.1' :), thank you Scyllinice.
  * Initial tag code. Bugfix for ree: add --no-tcmalloc to install, thank you r38y
  * Added abillity to remove a named gem set.
  * Remove gem directories for versions on uninstall.
  * Added gem set support.
  * Bugfix in install script. Thank you ddfreyne.
  * Fix to install script, thanks Tsykoduk
  * Bugfix, odd typo. Cleaning up code.
  * Fixed ree (again :)
  * IRB Support complete.
  * Added individual ruby IRBRC support.
  * Shuffled around directories so that things are closer to their final form early on.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Fixed: -h | --help | rvm usage | rvm help
  * Fixed rvm info. Merged with rvm debug secion. Improved rvm debug output.
  * Namespaced niceness to rvm_niceness.
  * Namespaced configure to rvm_ruby_configure
  * Added patch by Jim Lindley on how to 'install from source'.
  * You must export what you wish to use :)
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Change test for rvm source file to also check if greater than zero.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * No longer using -f check with curl since we are using the -C - flags.
  * Slightly improve error handling.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * We are (generally) not psychic, have curl automatically determine where to continue downloading.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Enable 'continue partial downloads' for curl, thanks Pistos\!
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Adjust rvm_{major,minor} version extraction to play nice with zsh...
  * Running a ruby file against all versions of ruby or just one now works.
  * Fixed ree install. Site updates.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master' of git@github.com:Pistos/rvm
  * Updated thank you's on site.
  * Adjusted path cleaning to remove trailing :
  * Refactoring complete. Testing needed.
  * Removed switching message now that we stay in the same shell.
  * Repaying technical debt. Refactoring.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * 'ls' is now referencing '/bin/ls' to avoid potential alias issues,   thanks Pistos!!!.
  * Make the about information show up again in the usage :)
  * Shortened usage and made it more maintainable at the same time, yay
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * More cleaning up, namespacing, working on support for 1.8.X
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Added awesome sed-fu patch by Chrononaut.

== Release 0.0.24: Quick, hide before she sees!

== Release 0.0.23: It works!
  * Completely separated out rvm's gems from system 1.8.
  * Added support for bin_path.
  * ree now works with it's own rubygems again. Seeing some oddities with 1.9.2.
  * Namespaced log_path. Rubygems now good for 1.8.X, still failing for ree.
  * Default variable bugfix. All ruby installs work. Rubygems install needs bugfix (gem isn't going to the correct location).
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Rename default_gem_path to default_user_gem_path
  * More namespacing.
  * Began the variable namespacing process.
  * Add rvm reload option.
  * Adjusted install & update based on feedback from Maz on IRC.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Download file check based on archive path.
  * Fixed prefix path checking and logic.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Merge branch 'master-upstream'
  * Defaulting log path properly to install_path/log
  * Changed variable defaults to use :- instead of simply -.
  * Added patch for archives, thanks to Pistos.
  * Applied niceness patch by Pistos.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * Removed pwd for install & update. Added /log to log path. Thanks Maz.
  * Removed lots of trailing whitespace for Pistos.
  * Bugfix for zsh in rvm-install. Abstracted log dir.
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm
  * ~/.rvm/log. Hook into .bashrc also. Install all bugfix. Install script capability testing cleanup.
  * Merge branch 'zsh'
  * Merge branch 'english-changes'
  * Merge branch 'master' of git://github.com/wayneeseguin/rvm

== Release 0.0.22: Let it Snow Leopards
  * Merge commit 'a8e55b29195f15b773dd698beb236493f372efdd'; branch 'site'
  * Credit Pistos, add patch by Caius Durling.
  * Merge branch 'master' into site

== Release 0.0.21. Is there a cure for stupidity?

== Release 0.0.20. Bugfix: zsh using curl. Bugfix: REE Uninstall.
  * Fixed ree uninstall bug.
  * 'Ignore built gems.' -- Pistos
  * 'Added evals to  calls, to satisfy zsh' -- Pistos
  * Added evals to $curl calls, to satisfy zsh.
  * Merge branch 'master' of git@github.com:Pistos/rvm
  * freenod -> freenode
  * Ignore built gems.
  * Added rvm symlinks to generate ~/.rvm/bin/ binary symlinks. Fixed RUBYOPT 'bug' when installing ree.
  * Added rvm symlinks
  * Fixed documentation error in the installer.
  * Updated Site.
  * Updated README and website to http://rvm.beginrescueend.com/
  * Latest site.
  * Website initial just about ready.
  * Unset GEM_HOME and MY_RUBY_HOME on default switch.
  * gemdup getting there...

== Release 0.0.18.
  * Adjusted rvm debug.
  * Parital gemdup functionality (default & system).
  * Added system default ruby to rvm list.
  * rvm reset now works proper for hard system reset.
  * Adding rvm-update.
  * Added rvm reset feature.

== Release 0.0.16. Many documentation typo fixes. Added Install section to usage. Added more thank you's. Added curl detection (for Ubuntu). Added force to symlinks. Fixed gemdir system/user. Added both shells option to install. Improved wording of rvm-install script.
  * Bugfix on source pat.
  * Installer now prompts for manual install and is much more forthcoming and helpful.

== Release 0.0.14. Bitten by RubyGems.

== Release 0.0.13. Bugfix in mkdir for source dirs.
  * Namespaced logging functions.
  * Refined debug.

== Release 0.0.11. rvm gemdir functional.
  * Updated Readme.
  * rvm gemdir now functions.

== Release 0.0.10. rvm default and switching now work properly with the path. Began prepairing for abstraction.
  * Label gemdup TODO
  * Updated README
  * Added rvm list.
  * Updated README
  * Uninstall now works.
  * Added sanity check for rvm-install to deny installation as root.

== Release 0.0.8
  * Debug switch now works. Added root sanity check.

== Release 0.0.7
  * Addded gemdup example. Fixed a rather embarassing typo.

== Release 0.0.6
  * Installations are now verbose and clean. REE now works properly. rvm -v|--version alone now displays the version of rvm.
  * Updated usage & readme.
  * When not specifying implementation and version, set to default.
  * Added Credits & Website
  * Added version and author line and updated wording for usage/docs. Removed rubinius plans for now.
  * Don't depend on uninstall.
  * Added default task => :gem
  * Updated rake gem
  * Added initial zsh support.
  * un-DRY curl.
  * Properly namespace all rvm functions with rvm-.
  * Added 1.9.2 support. Added per interpreter rubygems install (for source installs).
  * Added --configure option override. Fixed a typo.
  * Typo fix. Merged two variables that were the same except in name.
  * gemdir and srcdir now work as advertised.
  * Improved usage documentation. Removed path, rvm-setup, leopard (redundant to default).
  * Added debug action. Added all install. Added RVM module place holder. Removed package manager option, this should be for system default control.
  * Added LICENCE file to gem build.
  * Fixed executable permissions for jruby.
  * Prepairing for first release.
  * gemdup stil needs some love but we're good to go.
  * About to refactor.
  * Correctly refer to the bash/rvm-setup script for setup option.
  * Added LICENCE File.
  * Adjusted the rvm command so that it does not hijack the cwd.
  * Initial Gem version.
  * Switched source and package to simply prefix.
  * Updated path order and installer.
  * Added Installer.
  * Initial rvm, ruby, jruby, leopard functional.
